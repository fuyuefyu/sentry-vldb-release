#!/usr/bin/env bash
set -euo pipefail

python -m sentry_toy.cli all --config configs/toy.yaml
