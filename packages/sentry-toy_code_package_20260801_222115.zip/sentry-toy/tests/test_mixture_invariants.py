from pathlib import Path

from sentry_toy.reporting import run_mixture_invariant


def test_whole_response_and_rowwise_mixture_differ(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    Path("results").mkdir()
    result = run_mixture_invariant({"seed": 123}, draws=20_000)
    assert result["passed"]
    assert result["whole_response_mean"] == 1.0
    assert 0.48 <= result["row_wise_mean"] <= 0.52
