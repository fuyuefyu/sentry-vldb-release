import duckdb
import numpy as np
import pandas as pd

from sentry_toy.compiler import compiled_topk_sql, exhaustive_topk, python_topk


def test_compiler_matches_python_and_exhaustive_with_ties():
    df = pd.DataFrame(
        {
            "split": ["unit"] * 5,
            "context_id": [1] * 5,
            "x1": [0] * 5,
            "x2": [1] * 5,
            "item_id": np.arange(5, dtype=np.int64),
            "category": [1, 0, 1, 2, 3],
            "base_score": [0.0] * 5,
            "state_score_0": [1.0, 1.0, 0.8, 0.7, 0.6],
            "state_score_1": [0.6, 0.7, 0.8, 1.0, 1.0],
            "audit_category_1": [1.0, 0.0, 1.0, 0.0, 0.0],
            "audit_risk": [0.2, 0.1, 0.4, 0.3, 0.0],
            "tie_key": np.arange(5, dtype=np.int64),
        }
    )
    con = duckdb.connect(":memory:")
    con.register("candidate_df", df)
    con.execute("CREATE TABLE candidate AS SELECT * FROM candidate_df")
    out = compiled_topk_sql(con, "unit", 1, 0, 3, eta_category=0.0, eta_risk=0.0)
    sql_ids = out["item_id"].tolist()
    assert sql_ids == python_topk(df, 0, 3, 0.0, 0.0)
    assert sql_ids == exhaustive_topk(df, 0, 3, 0.0, 0.0)
    con.close()
