import pandas as pd

from sentry_toy.master_lp import solve_master


def test_master_lp_selects_feasible_mixture():
    cfg = {"predicates": ["global"], "views": {"additive": ["discounted_category_1_exposure"]}, "optimizer": {"development_tau": 0.1}}
    utility = pd.DataFrame({"component_id": ["aware", "ind"], "objective": [1.0, 0.5]})
    gaps = pd.DataFrame(
        {
            "component_id": ["aware", "ind"],
            "predicate": ["global", "global"],
            "view": ["discounted_category_1_exposure", "discounted_category_1_exposure"],
            "gap": [0.3, 0.0],
        }
    )
    result = solve_master(utility, gaps, cfg)
    assert abs(sum(result["gamma"].values()) - 1.0) <= 1e-8
    assert result["objective"] >= 0.5
