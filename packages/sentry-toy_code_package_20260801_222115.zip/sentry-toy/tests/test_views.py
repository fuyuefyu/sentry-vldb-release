import pandas as pd

from sentry_toy.views import gap_table, transcript_views


def test_views_are_in_unit_interval():
    transcript = pd.DataFrame(
        {
            "component_id": ["c"] * 6,
            "split": ["development"] * 6,
            "context_id": [0, 0, 0, 0, 0, 0],
            "state": [0, 0, 0, 1, 1, 1],
            "x1": [1, 1, 1, 1, 1, 1],
            "x2": [0, 0, 0, 0, 0, 0],
            "rank": [1, 2, 3, 1, 2, 3],
            "item_id": [1, 2, 3, 4, 5, 6],
            "category": [1, 0, 0, 0, 1, 1],
            "audit_risk": [0.2, 0.3, 0.4, 0.4, 0.3, 0.2],
            "utility_score": [1, 0, 0, 1, 0, 0],
        }
    )
    views = transcript_views(transcript, 3)
    for col in ["discounted_category_1_exposure", "discounted_risk_exposure", "top1_category_1", "max_category_concentration"]:
        assert ((views[col] >= 0) & (views[col] <= 1)).all()
    gaps = gap_table(views, {"predicates": ["global"]}, ["discounted_category_1_exposure"])
    assert len(gaps) == 1
