from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml

from .utils import ensure_dir


def load_config(path: str | Path) -> dict[str, Any]:
    cfg_path = Path(path)
    with cfg_path.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    cfg["_config_path"] = str(cfg_path)
    return cfg


def prepare_paths(cfg: dict[str, Any]) -> None:
    for d in ("results", "figures", "artifacts", "artifacts/explain"):
        ensure_dir(d)
    ensure_dir(Path(cfg["database"]["path"]).parent)


def smoke_like(cfg: dict[str, Any]) -> dict[str, Any]:
    out = deepcopy(cfg)
    out["data"]["development_contexts"] = min(int(out["data"]["development_contexts"]), 40)
    out["data"]["validation_contexts"] = min(int(out["data"]["validation_contexts"]), 120)
    out["data"]["test_contexts"] = min(int(out["data"]["test_contexts"]), 240)
    out["data"]["candidates_per_context"] = min(int(out["data"]["candidates_per_context"]), 30)
    out["benchmark"]["candidate_counts"] = [100, 1000]
    out["benchmark"]["warmup_runs"] = 1
    out["benchmark"]["measured_runs"] = 3
    return out
