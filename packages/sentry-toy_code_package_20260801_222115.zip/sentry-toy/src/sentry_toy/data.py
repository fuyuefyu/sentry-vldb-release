from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .database import connect_database, finalize_candidate_table, reset_candidate_table
from .utils import collect_environment, write_json


def _split_context_count(cfg: dict[str, Any], split: str) -> int:
    key = {
        "development": "development_contexts",
        "validation": "validation_contexts",
        "test": "test_contexts",
    }[split]
    return int(cfg["data"][key])


def _make_split(cfg: dict[str, Any], split: str, context_offset: int, rng: np.random.Generator) -> pd.DataFrame:
    n_contexts = _split_context_count(cfg, split)
    candidates = int(cfg["data"]["candidates_per_context"])
    categories = int(cfg["data"]["categories"])
    rows: list[pd.DataFrame] = []
    leak = float(cfg["data"].get("state_context_weight", 0.35))
    risk_weight = float(cfg["data"].get("risk_weight", 0.08))
    noise_sd = float(cfg["data"].get("score_noise", 0.015))
    for start in range(0, n_contexts, 256):
        stop = min(start + 256, n_contexts)
        context_local = np.arange(start, stop, dtype=np.int64)
        context_id = context_offset + context_local
        x1 = (context_local % 2).astype(np.int64)
        x2 = ((context_local // 2) % 2).astype(np.int64)
        rep_context = np.repeat(context_id, candidates)
        rep_x1 = np.repeat(x1, candidates)
        rep_x2 = np.repeat(x2, candidates)
        item_ix = np.tile(np.arange(candidates, dtype=np.int64), stop - start)
        item_id = rep_context * 1_000_000 + item_ix
        pair_id = context_local // 2
        unique_pairs, pair_inverse = np.unique(pair_id, return_inverse=True)
        pair_category = rng.integers(0, categories, size=(len(unique_pairs), candidates), endpoint=False)
        pair_base = rng.normal(0.0, 0.35, size=(len(unique_pairs), candidates))
        pair_risk = np.clip(
            0.15 + 0.7 * rng.beta(2.0, 4.0, size=(len(unique_pairs), candidates)) + 0.12 * (pair_category == 1),
            0.0,
            1.0,
        )
        pair_noise_pos = rng.normal(0.0, noise_sd, size=(len(unique_pairs), candidates))
        pair_noise_neg = rng.normal(0.0, noise_sd, size=(len(unique_pairs), candidates))
        category = pair_category[pair_inverse, :].reshape(-1)
        category_signal = np.where(category == 1, 1.0, -0.35)
        audit_category_1 = (category == 1).astype(float)
        base_score = pair_base[pair_inverse, :].reshape(-1)
        audit_risk = pair_risk[pair_inverse, :].reshape(-1)
        context_sign = np.where(rep_x1 == 1, 1.0, -1.0)
        scores = {}
        for z in (0, 1):
            state_sign = 1.0 if z == 1 else -1.0
            product_sign = context_sign * state_sign
            noise = np.where(
                product_sign > 0,
                pair_noise_pos[pair_inverse, :].reshape(-1),
                pair_noise_neg[pair_inverse, :].reshape(-1),
            )
            scores[z] = (
                base_score
                + leak * context_sign * state_sign * category_signal
                + risk_weight * state_sign * audit_risk
                + noise
            )
        rows.append(
            pd.DataFrame(
                {
                    "split": split,
                    "context_id": rep_context,
                    "x1": rep_x1,
                    "x2": rep_x2,
                    "item_id": item_id,
                    "category": category.astype(np.int64),
                    "base_score": base_score,
                    "state_score_0": scores[0],
                    "state_score_1": scores[1],
                    "audit_category_1": audit_category_1,
                    "audit_risk": audit_risk,
                    "tie_key": item_id,
                }
            )
        )
    return pd.concat(rows, ignore_index=True)


def generate(cfg: dict[str, Any], overwrite: bool = False) -> dict[str, Any]:
    db_path = Path(cfg["database"]["path"])
    if db_path.exists() and not overwrite:
        return {"database": str(db_path), "skipped": True}
    if db_path.exists():
        db_path.unlink()
    con = connect_database(cfg)
    reset_candidate_table(con)
    rng = np.random.default_rng(int(cfg["seed"]))
    offsets = {"development": 0, "validation": 1_000_000, "test": 2_000_000}
    counts = {}
    for split in ("development", "validation", "test"):
        df = _make_split(cfg, split, offsets[split], rng)
        counts[split] = {"contexts": _split_context_count(cfg, split), "rows": int(len(df))}
        con.register("candidate_chunk", df)
        con.execute("INSERT INTO candidate SELECT * FROM candidate_chunk")
        con.unregister("candidate_chunk")
    finalize_candidate_table(con)
    total = con.execute("SELECT count(*) FROM candidate").fetchone()[0]
    con.close()
    env = collect_environment(Path.cwd(), db_path)
    out = {"database": str(db_path), "rows": int(total), "splits": counts, "environment": env}
    write_json("results/generation_summary.json", out)
    write_json("results/environment.json", env)
    return out
