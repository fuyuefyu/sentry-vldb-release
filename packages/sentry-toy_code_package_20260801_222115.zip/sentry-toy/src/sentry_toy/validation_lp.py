from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.optimize import linprog

from .database import connect_database
from .transcript import component_spec, materialize_components
from .utils import write_json
from .views import FULL_COLUMNS, component_summary, gap_table, transcript_views, worst_gap


def _load_components() -> dict[str, Any]:
    return json.loads(Path("results/components.json").read_text(encoding="utf-8"))


def _radii(cfg: dict[str, Any], k_components: int, gaps: pd.DataFrame) -> tuple[dict[str, float], float]:
    delta = float(cfg["certificate"]["delta"])
    edge_count = 1
    m = len(cfg["views"]["full"])
    radii = {}
    for predicate, sub in gaps.groupby("predicate"):
        n_c = max(1, int(sub["n_c"].max()))
        radii[predicate] = math.sqrt(2.0 * math.log(4 * k_components * edge_count * len(cfg["predicates"]) * m / delta) / n_c)
    n_u = int(cfg["data"]["validation_contexts"])
    r_u = math.sqrt(math.log(4 * k_components / delta) / (2 * n_u))
    return radii, r_u


def _validation_lp(cfg: dict[str, Any], utility: pd.DataFrame, gaps: pd.DataFrame, radii: dict[str, float]) -> dict[str, Any]:
    component_ids = utility["component_id"].tolist()
    u = utility.set_index("component_id").loc[component_ids]["objective"].to_numpy(dtype=float)
    rows = []
    b = []
    tau = float(cfg["certificate"]["tau"])
    for predicate in cfg["predicates"]:
        for view in cfg["views"]["full"]:
            vals = []
            for cid in component_ids:
                g = gaps[(gaps["component_id"] == cid) & (gaps["predicate"] == predicate) & (gaps["view"] == view)]["gap"].iloc[0]
                vals.append(float(g))
            cap = tau - radii[predicate]
            rows.append(vals)
            b.append(cap)
            rows.append([-v for v in vals])
            b.append(cap)
    res = linprog(
        c=-u,
        A_ub=np.asarray(rows),
        b_ub=np.asarray(b),
        A_eq=np.ones((1, len(component_ids))),
        b_eq=np.array([1.0]),
        bounds=[(0, None)] * len(component_ids),
        method="highs",
    )
    if res.success:
        gamma = {cid: float(x) for cid, x in zip(component_ids, res.x) if x > 1e-10}
        return {"success": True, "gamma": gamma, "objective": float(-res.fun), "status": res.message}
    return {"success": False, "gamma": {"state_independent": 1.0}, "objective": None, "status": res.message}


def mixture_views(views: pd.DataFrame, gamma: dict[str, float]) -> pd.DataFrame:
    rows = []
    group_cols = ["split", "context_id", "state", "x1", "x2"]
    for key, grp in views.groupby(group_cols):
        row = dict(zip(group_cols, key))
        for col in ["utility"] + FULL_COLUMNS:
            row[col] = float(sum(float(gamma.get(r.component_id, 0.0)) * float(getattr(r, col)) for r in grp.itertuples()))
        row["component_id"] = "mixture"
        rows.append(row)
    return pd.DataFrame(rows)


def run_certificate(cfg: dict[str, Any], resume: bool = False) -> dict[str, Any]:
    if resume and Path("results/certificate_summary.json").exists():
        return json.loads(Path("results/certificate_summary.json").read_text(encoding="utf-8"))
    comp = _load_components()
    specs = comp["components"]
    con = connect_database(cfg)
    val_transcript = materialize_components(con, cfg, specs, "validation")
    val_views = transcript_views(val_transcript, int(cfg["ranking"]["k"]))
    val_utility, val_gaps = component_summary(val_views, cfg, list(cfg["views"]["full"]))
    radii, r_u = _radii(cfg, len(specs), val_gaps)
    lp = _validation_lp(cfg, val_utility, val_gaps, radii)
    fallback = not lp["success"]
    gamma = lp["gamma"]
    mix_val = mixture_views(val_views, gamma)
    mix_val_gaps = gap_table(mix_val, cfg, list(cfg["views"]["full"]))
    test_transcript = materialize_components(con, cfg, specs, "test")
    test_views_all = transcript_views(test_transcript, int(cfg["ranking"]["k"]))
    mix_test = mixture_views(test_views_all, gamma)
    mix_test_gaps = gap_table(mix_test, cfg, list(cfg["views"]["full"]))
    test_gap = worst_gap(mix_test, cfg, list(cfg["views"]["full"]))
    state_aware = test_views_all[test_views_all["component_id"] == "state_aware"]["utility"].mean()
    state_ind = test_views_all[test_views_all["component_id"] == "state_independent"]["utility"].mean()
    utility = mix_test["utility"].mean()
    denom = max(1e-12, float(state_aware - state_ind))
    retention_sa = float(utility / state_aware) if abs(state_aware) > 1e-12 else None
    retention_interval = float((utility - state_ind) / denom)
    con.close()
    cert_rows = []
    for predicate in cfg["predicates"]:
        n_c = int(val_gaps[val_gaps["predicate"] == predicate]["n_c"].max())
        for view in cfg["views"]["full"]:
            val_row = mix_val_gaps[(mix_val_gaps["predicate"] == predicate) & (mix_val_gaps["view"] == view)].iloc[0]
            test_row = mix_test_gaps[(mix_test_gaps["predicate"] == predicate) & (mix_test_gaps["view"] == view)].iloc[0]
            cert_rows.append(
                {
                    "predicate": predicate,
                    "view": view,
                    "n_c": n_c,
                    "r_L_c": radii[predicate],
                    "n_U": int(cfg["data"]["validation_contexts"]),
                    "r_U": r_u,
                    "validation_gap": float(val_row["gap"]),
                    "validation_abs_gap": float(val_row["abs_gap"]),
                    "test_gap": float(test_row["gap"]),
                    "test_abs_gap": float(test_row["abs_gap"]),
                    "tau": float(cfg["certificate"]["tau"]),
                    "validation_cap": float(cfg["certificate"]["tau"]) - radii[predicate],
                    "fallback": bool(fallback),
                    "support_size": len(gamma),
                }
            )
    cert_df = pd.DataFrame(cert_rows)
    cert_df.to_csv("results/certificate.csv", index=False)
    summary = {
        "validation_success": bool(lp["success"]),
        "fallback": bool(fallback),
        "gamma": gamma,
        "n_U": int(cfg["data"]["validation_contexts"]),
        "n_T": int(cfg["data"]["test_contexts"]),
        "r_U": r_u,
        "test_worst_registered_gap": float(test_gap),
        "tau": float(cfg["certificate"]["tau"]),
        "toy_tolerance": 0.02,
        "absolute_utility": float(utility),
        "utility_retention_vs_state_aware": retention_sa,
        "utility_retention_vs_state_independent": retention_interval,
        "support_size": len(gamma),
        "passed": bool((lp["success"] or fallback) and test_gap <= float(cfg["certificate"]["tau"]) + 0.02),
    }
    try:
        from .reporting import plot_utility_gap_frontier

        plot_utility_gap_frontier(val_utility, val_gaps, gamma, summary)
    except Exception as exc:
        summary["figure_error"] = str(exc)
    write_json("results/certificate_summary.json", summary)
    return summary
