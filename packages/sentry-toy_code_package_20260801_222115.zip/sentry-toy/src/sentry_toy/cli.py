from __future__ import annotations

import argparse
import time
from pathlib import Path

from .benchmarks import run_benchmark
from .config import load_config, prepare_paths
from .data import generate
from .explicit_lp import run_explicit_lp
from .master_lp import run_optimizer
from .reporting import build_report, run_cancellation, run_correctness, run_mixture_invariant, run_unit_tests
from .utils import collect_environment, write_json
from .validation_lp import run_certificate


def _load(path: str) -> dict:
    cfg = load_config(path)
    prepare_paths(cfg)
    return cfg


def _add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--config", default="configs/toy.yaml")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--skip-benchmark", action="store_true")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="sentry_toy")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ["generate", "correctness", "cancellation", "optimize", "explicit-lp", "certify", "benchmark", "mixture", "test", "report", "all"]:
        _add_common(sub.add_parser(name))
    args = parser.parse_args(argv)
    cfg = _load(args.config)
    start = time.perf_counter()
    write_json("results/environment.json", {**collect_environment(Path.cwd(), Path(cfg["database"]["path"])), "start_time": time.strftime("%Y-%m-%d %H:%M:%S %z")})
    if args.command == "generate":
        generate(cfg, overwrite=args.overwrite)
    elif args.command == "correctness":
        run_correctness(cfg, resume=args.resume)
    elif args.command == "cancellation":
        run_cancellation(cfg, resume=args.resume)
    elif args.command == "optimize":
        run_optimizer(cfg, resume=args.resume)
    elif args.command == "explicit-lp":
        run_explicit_lp(cfg, resume=args.resume)
    elif args.command == "certify":
        run_certificate(cfg, resume=args.resume)
    elif args.command == "benchmark":
        run_benchmark(cfg, resume=args.resume)
    elif args.command == "mixture":
        run_mixture_invariant(cfg, resume=args.resume)
    elif args.command == "test":
        run_unit_tests(resume=args.resume)
    elif args.command == "report":
        build_report(cfg, runtime_seconds=time.perf_counter() - start)
    elif args.command == "all":
        generate(cfg, overwrite=args.overwrite)
        run_correctness(cfg, resume=args.resume)
        run_cancellation(cfg, resume=args.resume)
        run_optimizer(cfg, resume=args.resume)
        run_explicit_lp(cfg, resume=args.resume)
        run_certificate(cfg, resume=args.resume)
        run_mixture_invariant(cfg, resume=args.resume)
        if not args.skip_benchmark:
            run_benchmark(cfg, resume=args.resume)
        run_unit_tests(resume=args.resume)
        build_report(cfg, runtime_seconds=time.perf_counter() - start)
    else:
        raise ValueError(args.command)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
