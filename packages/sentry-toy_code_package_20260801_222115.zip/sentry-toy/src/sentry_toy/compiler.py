from __future__ import annotations

import itertools
from typing import Any

import duckdb
import numpy as np
import pandas as pd

from .utils import active_predicates, position_weights


STATE_SCORE_COLUMNS = {0: "state_score_0", 1: "state_score_1"}


def score_expression(state: int, score_mode: str = "state") -> str:
    if score_mode == "state":
        if state not in STATE_SCORE_COLUMNS:
            raise ValueError(f"invalid state: {state}")
        return STATE_SCORE_COLUMNS[state]
    if score_mode == "state_independent":
        return "(0.5 * (state_score_0 + state_score_1))"
    raise ValueError(f"invalid score mode: {score_mode}")


def compiled_topk_sql(
    con: duckdb.DuckDBPyConnection,
    split: str,
    context_id: int,
    state: int,
    k: int,
    alpha: float = 1.0,
    eta_category: float = 0.0,
    eta_risk: float = 0.0,
    component_id: str = "component",
    score_mode: str = "state",
) -> pd.DataFrame:
    state_expr = score_expression(state, score_mode)
    sql = f"""
        SELECT
            context_id,
            x1,
            x2,
            item_id,
            category,
            audit_category_1,
            audit_risk,
            state_score_0,
            state_score_1,
            ({alpha} * {state_expr} - ? * audit_category_1 - ? * audit_risk) AS adjusted_score
        FROM candidate
        WHERE split = ? AND context_id = ?
        ORDER BY adjusted_score DESC, tie_key ASC
        LIMIT ?
    """
    df = con.execute(sql, [float(eta_category), float(eta_risk), split, int(context_id), int(k)]).fetchdf()
    df.insert(1, "state", int(state))
    df.insert(2, "component_id", component_id)
    df.insert(3, "rank", np.arange(1, len(df) + 1, dtype=int))
    df["fallback"] = score_mode == "state_independent"
    df["utility_score"] = np.where(df["state"] == 0, df["state_score_0"], df["state_score_1"])
    return df


def python_topk(df: pd.DataFrame, state: int, k: int, eta_category: float, eta_risk: float) -> list[int]:
    state_col = STATE_SCORE_COLUMNS[state]
    tmp = df.copy()
    tmp["adjusted_score"] = tmp[state_col] - eta_category * tmp["audit_category_1"] - eta_risk * tmp["audit_risk"]
    tmp = tmp.sort_values(["adjusted_score", "tie_key"], ascending=[False, True])
    return [int(x) for x in tmp.head(k)["item_id"].tolist()]


def exhaustive_topk(df: pd.DataFrame, state: int, k: int, eta_category: float, eta_risk: float) -> list[int]:
    state_col = STATE_SCORE_COLUMNS[state]
    tmp = df.copy()
    tmp["adjusted_score"] = tmp[state_col] - eta_category * tmp["audit_category_1"] - eta_risk * tmp["audit_risk"]
    scores = dict(zip(tmp["item_id"], tmp["adjusted_score"]))
    ties = dict(zip(tmp["item_id"], tmp["tie_key"]))
    best_perm: tuple[int, ...] | None = None
    best_key: tuple[float, ...] | None = None
    for perm in itertools.permutations([int(x) for x in tmp["item_id"]], k):
        key = tuple(v for i in perm for v in (scores[i], -ties[i]))
        if best_key is None or key > best_key:
            best_key = key
            best_perm = perm
    return list(best_perm or [])


def eta_from_theta(cfg: dict[str, Any], slice_counts: dict[str, int], theta: dict[str, dict[str, float]], x1: int, x2: int, state: int) -> tuple[float, float]:
    n_dev = int(cfg["data"]["development_contexts"])
    sign = 1.0 if state == 0 else -1.0
    cat_coeff = 0.0
    risk_coeff = 0.0
    for predicate in active_predicates(list(cfg["predicates"]), int(x1), int(x2)):
        n_c = max(1, int(slice_counts[predicate]))
        kappa = n_dev / n_c
        cat_coeff += sign * kappa * float(theta.get(predicate, {}).get("discounted_category_1_exposure", 0.0))
        risk_coeff += sign * kappa * float(theta.get(predicate, {}).get("discounted_risk_exposure", 0.0))
    return -cat_coeff, -risk_coeff


def context_table(con: duckdb.DuckDBPyConnection, split: str, limit: int | None = None) -> pd.DataFrame:
    lim = "" if limit is None else f" LIMIT {int(limit)}"
    return con.execute(
        f"SELECT DISTINCT context_id, x1, x2 FROM candidate WHERE split = ? ORDER BY context_id{lim}",
        [split],
    ).fetchdf()


def slice_counts(con: duckdb.DuckDBPyConnection, cfg: dict[str, Any], split: str = "development") -> dict[str, int]:
    contexts = context_table(con, split)
    counts = {}
    for predicate in cfg["predicates"]:
        mask = [predicate in active_predicates(list(cfg["predicates"]), int(r.x1), int(r.x2)) for r in contexts.itertuples()]
        counts[predicate] = int(np.sum(mask))
    return counts
