# SENTRY Toy Validation Report

## 1. Scope and non-goals

This toy experiment validates the execution and optimization mechanisms on a controlled workload. It does not establish large-scale production practicality, workload generality, or a privacy guarantee beyond the registered audit view.

## 2. Environment

- Status: PASS
- OS: Linux-7.0.0-28-generic-x86_64-with-glibc2.43
- Python: 3.14.4 (main, Jun 18 2026, 14:25:02) [GCC 15.2.0]
- DuckDB: 1.5.5
- CPU cores: physical=24, logical=32
- Memory: total=66084564992, available=44915380224
- Database bytes: 59256832

## 3. Synthetic workload

- Development contexts: 600
- Validation contexts: 4000
- Test contexts: 8000
- Candidates per context: 80
- Registered predicates: global, x1_eq_0, x1_eq_1, x2_eq_1, x1_eq_1_and_x2_eq_1

## 4. Context-cancellation result

- Status: PASS
- Max absolute global signed gap: 0.0
- Max conditional absolute gap: 0.7651811477995833

## 5. SQL compiler correctness

- Status: PASS
- Cases: 1000
- SQL/Python agreement: 1.0
- SQL/exhaustive agreement: 1.0

## 6. Column-generation versus explicit LP

- Column generation status: PASS
- CG iterations: 14
- Final recomputed reduced cost: 8.428406528260268e-09
- Explicit LP status: PASS
- Objective gap: 0.0

## 7. Held-out full-view certificate

- Status: PASS
- Validation success: True
- Fallback: False
- Test worst registered gap: 0.15348156671120858
- Support size: 4

## 8. Whole-response versus row-wise mixture

- Status: PASS
- Whole-response mean: 1.0
- Row-wise mean: 0.50086

## 9. SQL latency and throughput

- Status: PASS
- Latency records: 1080
- Concurrency records: 3
- Cache note: This is connection-cold, not an operating-system cold-cache benchmark.

## 10. Failures and limitations

- Missing latency configs: []
- Missing concurrency configs: []
- The toy validates registered audit views on synthetic data and should not be read as a production scalability or privacy proof.

## 11. Reproduction commands

```bash
python -m pip install -e .
python -m pytest -q
python -m sentry_toy.cli all --config configs/toy.yaml
```
