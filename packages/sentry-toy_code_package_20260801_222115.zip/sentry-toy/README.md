# SENTRY Toy End-to-End SQL Mechanism Validation

This repository is a DuckDB-backed toy prototype for validating the SENTRY
execution and optimization mechanisms on a controlled synthetic workload.

The one-command smoke reproduction is:

```bash
python -m pip install -e .
python -m pytest -q
python -m sentry_toy.cli all --config configs/smoke.yaml
```

For the full toy run:

```bash
python -m sentry_toy.cli all --config configs/toy.yaml
```

Python 3.11 or newer is required. On Windows, use `py -3.14 -m ...` or another
3.11+ interpreter if `python` points to an older installation.

The experiment writes all numeric outputs to `results/`, figures to `figures/`,
the DuckDB database to `artifacts/`, and representative `EXPLAIN ANALYZE` plans
to `artifacts/explain/`.

This toy experiment validates the execution and optimization mechanisms on a
controlled workload. It does not establish large-scale production practicality,
workload generality, or a privacy guarantee beyond the registered audit view.
