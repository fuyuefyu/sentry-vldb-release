# SENTRY VLDB Compile Package

This is the minimal manuscript compile bundle. It contains the filled LaTeX
source, bibliography output, local class/style files, referenced figures, the
generated certificate-disclosure table source, and the compiled PDF.

Compile locally from this directory with:

```bash
make pdf
```

or directly:

```bash
python scripts/compile_latex.py --tex main_revised_vldb_filled.tex --jobname main_revised_vldb_filled
```

The experiment and figure rebuild code is intentionally kept in
`SENTRY_VLDB_artifact.zip`. The compile package only compiles the already filled
manuscript source.
