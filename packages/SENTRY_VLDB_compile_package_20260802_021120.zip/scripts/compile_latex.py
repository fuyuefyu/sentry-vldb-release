from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(args: list[str]) -> int:
    print("$ " + " ".join(args), flush=True)
    completed = subprocess.run(args, cwd=ROOT)
    return completed.returncode


def compile_tex(tex: Path, jobname: str) -> int:
    tex_arg = str(tex)
    sequence = [
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", f"-jobname={jobname}", tex_arg],
        ["bibtex", jobname],
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", f"-jobname={jobname}", tex_arg],
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", f"-jobname={jobname}", tex_arg],
    ]
    for index, command in enumerate(sequence):
        code = run(command)
        if code != 0:
            if index == 1:
                print("bibtex failed; continuing only when no .aux was generated would hide a real reference problem.", file=sys.stderr)
            return code
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tex", required=True)
    parser.add_argument("--jobname", required=True)
    args = parser.parse_args()
    tex = Path(args.tex)
    if not tex.is_absolute():
        tex = ROOT / tex
    if not tex.exists():
        print(f"missing tex file: {tex}", file=sys.stderr)
        return 2
    return compile_tex(tex, args.jobname)


if __name__ == "__main__":
    raise SystemExit(main())
