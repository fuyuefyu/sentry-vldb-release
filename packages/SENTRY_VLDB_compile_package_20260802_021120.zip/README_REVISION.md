# SENTRY VLDB Compile Package

This is the minimal manuscript compile bundle. It contains the filled LaTeX
source, bibliography output, local class/style files, referenced figures, the
generated certificate-disclosure table source, and the compiled PDF.

Compile locally from this directory with:

```bash
make pdf
```

or directly:

```bash
python scripts/compile_latex.py --tex main_revised_vldb_filled.tex --jobname main_revised_vldb_filled
```

The six RQ figures referenced by the manuscript are:

- `figures/rq1_context_metadata.pdf`
- `figures/rq2_end_to_end_frontier.pdf`
- `figures/rq3_certificate_application.pdf`
- `figures/rq4_generality.pdf`
- `figures/rq5_planner_system.pdf`
- `figures/rq6_residual_attack.pdf`

The code that regenerates the plotted data and exports these figures is kept in
`SENTRY_VLDB_artifact.zip`. This compile package only compiles the manuscript
from the already generated figure and table files.
