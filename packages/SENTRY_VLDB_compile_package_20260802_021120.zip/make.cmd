@echo off
"C:\Strawberry\c\bin\mingw32-make.exe" %*
