from sentry_validation.cli import main


if __name__ == "__main__":
    raise SystemExit(main(["optimize"]))

