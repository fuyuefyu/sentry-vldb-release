#!/usr/bin/env bash
set -euo pipefail

python -m sentry_validation.cli all --config configs/validation.yaml

