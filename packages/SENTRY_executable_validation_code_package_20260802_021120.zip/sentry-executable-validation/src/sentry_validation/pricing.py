from __future__ import annotations

from typing import Any

import numpy as np


def theta_from_duals(cfg: dict[str, Any], dual_rows: list[float]) -> dict[str, dict[str, float]]:
    theta: dict[str, dict[str, float]] = {}
    idx = 0
    for predicate in cfg["predicates"]:
        theta[predicate] = {}
        for view in cfg["views"]["additive"]:
            plus = float(dual_rows[idx])
            minus = float(dual_rows[idx + 1])
            theta[predicate][view] = 2.0 * (plus - minus)
            idx += 2
    return theta


def fallback_theta(cfg: dict[str, Any], scale: float) -> dict[str, dict[str, float]]:
    theta: dict[str, dict[str, float]] = {}
    for predicate in cfg["predicates"]:
        theta[predicate] = {
            "discounted_category_1_exposure": -scale,
            "discounted_risk_exposure": -0.2 * scale,
        }
    return theta


def canonicalize_theta(theta: dict[str, dict[str, float]], ndigits: int = 8) -> dict[str, dict[str, float]]:
    return {
        p: {v: float(np.round(x, ndigits)) for v, x in cols.items()}
        for p, cols in theta.items()
    }

