from __future__ import annotations

from pathlib import Path
from typing import Any

import duckdb


def connect_database(cfg: dict[str, Any], read_only: bool = False) -> duckdb.DuckDBPyConnection:
    db_path = Path(cfg["database"]["path"])
    con = duckdb.connect(str(db_path), read_only=read_only)
    con.execute(f"PRAGMA threads={int(cfg['database'].get('threads', 1))}")
    memory = cfg["database"].get("memory_limit")
    if memory:
        con.execute(f"PRAGMA memory_limit='{memory}'")
    return con


def reset_candidate_table(con: duckdb.DuckDBPyConnection) -> None:
    con.execute("DROP TABLE IF EXISTS candidate")
    con.execute(
        """
        CREATE TABLE candidate (
            split VARCHAR NOT NULL,
            context_id BIGINT NOT NULL,
            x1 INTEGER NOT NULL,
            x2 INTEGER NOT NULL,
            item_id BIGINT NOT NULL,
            category INTEGER NOT NULL,
            base_score DOUBLE NOT NULL,
            state_score_0 DOUBLE NOT NULL,
            state_score_1 DOUBLE NOT NULL,
            audit_category_1 DOUBLE NOT NULL,
            audit_risk DOUBLE NOT NULL,
            tie_key BIGINT NOT NULL
        )
        """
    )


def finalize_candidate_table(con: duckdb.DuckDBPyConnection) -> None:
    con.execute("CREATE INDEX IF NOT EXISTS idx_candidate_context ON candidate(split, context_id)")
    con.execute("ANALYZE candidate")

