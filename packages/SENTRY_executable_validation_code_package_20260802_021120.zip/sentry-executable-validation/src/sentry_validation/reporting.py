from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import duckdb
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .compiler import compiled_topk_sql, exhaustive_topk, python_topk
from .database import connect_database
from .transcript import component_spec, materialize_component
from .utils import collect_environment, status, write_json
from .views import component_summary, gap_table, transcript_views, worst_gap


def configure_matplotlib() -> None:
    plt.rcParams.update(
        {
            "figure.dpi": 140,
            "savefig.dpi": 600,
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "font.size": 8,
            "axes.titlesize": 9,
            "axes.labelsize": 8,
            "axes.linewidth": 0.8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "lines.linewidth": 1.4,
            "patch.linewidth": 0.5,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )


def save_figure(fig: plt.Figure, stem: str | Path) -> None:
    stem_path = Path(stem)
    stem_path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    for suffix, kwargs in {
        ".png": {"dpi": 600},
        ".svg": {},
        ".pdf": {},
        ".tiff": {"dpi": 600},
    }.items():
        fig.savefig(stem_path.with_suffix(suffix), bbox_inches="tight", **kwargs)
    plt.close(fig)


def _candidate_case(rng: np.random.Generator, case_id: int) -> tuple[pd.DataFrame, int, int, float, float]:
    n = int(rng.integers(4, 9))
    k = int(rng.integers(1, min(4, n) + 1))
    state = int(rng.integers(0, 2))
    item_id = np.arange(n, dtype=np.int64)
    category = rng.integers(0, 4, size=n)
    audit_category_1 = (category == 1).astype(float)
    audit_risk = rng.uniform(0.0, 1.0, size=n)
    base = rng.normal(0.0, 0.4, size=n)
    df = pd.DataFrame(
        {
            "split": "parity",
            "context_id": case_id,
            "x1": int(case_id % 2),
            "x2": int((case_id // 2) % 2),
            "item_id": item_id,
            "category": category.astype(np.int64),
            "base_score": base,
            "state_score_0": base + rng.normal(0.0, 0.1, size=n) - 0.2 * audit_category_1,
            "state_score_1": base + rng.normal(0.0, 0.1, size=n) + 0.2 * audit_category_1,
            "audit_category_1": audit_category_1,
            "audit_risk": audit_risk,
            "tie_key": item_id,
        }
    )
    if case_id % 23 == 0:
        df.loc[df.index[:2], "state_score_0"] = 0.0
        df.loc[df.index[:2], "state_score_1"] = 0.0
        df.loc[df.index[:2], "audit_category_1"] = 0.0
        df.loc[df.index[:2], "audit_risk"] = 0.0
    return df, state, k, float(rng.uniform(0.0, 1.0)), float(rng.uniform(0.0, 0.5))


def run_correctness(cfg: dict[str, Any], resume: bool = False) -> dict[str, Any]:
    out_csv = Path("results/compiler_parity.csv")
    out_json = Path("results/compiler_summary.json")
    if resume and out_csv.exists() and out_json.exists():
        return json.loads(out_json.read_text(encoding="utf-8"))
    rng = np.random.default_rng(int(cfg["seed"]) + 17)
    cases = max(1000, int(cfg.get("correctness_cases", 1000)))
    con = duckdb.connect(":memory:")
    rows = []
    for case_id in range(cases):
        df, state, k, eta_category, eta_risk = _candidate_case(rng, case_id)
        con.register("candidate_df", df)
        con.execute("CREATE OR REPLACE TEMP TABLE candidate AS SELECT * FROM candidate_df")
        con.unregister("candidate_df")
        sql_df = compiled_topk_sql(
            con,
            split="parity",
            context_id=case_id,
            state=state,
            k=k,
            eta_category=eta_category,
            eta_risk=eta_risk,
            component_id="parity",
        )
        sql_ids = [int(x) for x in sql_df["item_id"].tolist()]
        py_ids = python_topk(df, state, k, eta_category, eta_risk)
        ex_ids = exhaustive_topk(df, state, k, eta_category, eta_risk)
        rows.append(
            {
                "seed": int(cfg["seed"]),
                "case_id": case_id,
                "context_id": case_id,
                "state": state,
                "candidate_count": int(len(df)),
                "k": k,
                "sql_item_ids": " ".join(map(str, sql_ids)),
                "python_item_ids": " ".join(map(str, py_ids)),
                "exhaustive_item_ids": " ".join(map(str, ex_ids)),
                "sql_python_match": bool(sql_ids == py_ids),
                "sql_exhaustive_match": bool(sql_ids == ex_ids),
            }
        )
    con.close()
    result = pd.DataFrame(rows)
    result.to_csv(out_csv, index=False)
    sql_python = float(result["sql_python_match"].mean())
    sql_exhaustive = float(result["sql_exhaustive_match"].mean())
    summary = {
        "cases": int(cases),
        "sql_python_agreement": sql_python,
        "sql_exhaustive_agreement": sql_exhaustive,
        "passed": bool(sql_python == 1.0 and sql_exhaustive == 1.0),
    }
    write_json(out_json, summary)
    return summary


def run_cancellation(cfg: dict[str, Any], resume: bool = False) -> dict[str, Any]:
    out_csv = Path("results/cancellation.csv")
    out_json = Path("results/cancellation_summary.json")
    if resume and out_csv.exists() and out_json.exists():
        return json.loads(out_json.read_text(encoding="utf-8"))
    con = connect_database(cfg)
    transcript = materialize_component(con, cfg, component_spec("state_aware", "state_aware"), "development")
    con.close()
    views = transcript_views(transcript, int(cfg["ranking"]["k"]))
    gaps = gap_table(views, cfg, list(cfg["views"]["additive"]))
    gaps = gaps.rename(columns={"gap": "signed_gap"})
    gaps["scope"] = np.where(gaps["predicate"] == "global", "global", "slice")
    global_abs = float(gaps[gaps["predicate"] == "global"]["abs_gap"].max())
    conditional = float(gaps[gaps["predicate"] != "global"]["abs_gap"].max())
    gaps["global_threshold"] = 0.05
    gaps["conditional_threshold"] = 0.15
    gaps.to_csv(out_csv, index=False)
    summary = {
        "max_abs_global_signed_gap": global_abs,
        "max_conditional_abs_gap": conditional,
        "global_threshold": 0.05,
        "conditional_threshold": 0.15,
        "passed": bool(global_abs <= 0.05 and conditional >= 0.15),
    }
    write_json(out_json, summary)
    plot_cancellation(gaps)
    return summary


def plot_cancellation(gaps: pd.DataFrame) -> None:
    configure_matplotlib()
    labels = []
    values = []
    colors = []
    for row in gaps.itertuples(index=False):
        labels.append(f"{row.predicate} | {row.view.replace('discounted_', '').replace('_', ' ')}")
        values.append(float(row.abs_gap if row.predicate != "global" else row.signed_gap))
        colors.append("#3b6ea8" if row.predicate == "global" else "#c44e52")
    order = np.argsort(np.abs(values))
    y = np.arange(len(values))
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    ax.axvline(0.05, color="#3b6ea8", linewidth=0.9, linestyle="--", label="global target")
    ax.axvline(0.15, color="#c44e52", linewidth=0.9, linestyle=":", label="slice target")
    ax.barh(y, np.asarray(values)[order], color=np.asarray(colors)[order], alpha=0.9)
    ax.set_xlabel("gap")
    ax.set_yticks(y)
    ax.set_yticklabels(np.asarray(labels, dtype=object)[order])
    ax.set_title("Context-conditional cancellation")
    ax.legend(frameon=False, ncol=2, loc="lower right")
    save_figure(fig, "figures/cancellation")


def plot_utility_gap_frontier(
    utility: pd.DataFrame,
    gaps: pd.DataFrame,
    gamma: dict[str, float],
    summary: dict[str, Any],
) -> None:
    configure_matplotlib()
    worst = gaps.groupby("component_id", as_index=False)["abs_gap"].max().rename(columns={"abs_gap": "worst_gap"})
    df = utility.merge(worst, on="component_id", how="left")
    df["support_weight"] = df["component_id"].map(gamma).fillna(0.0)
    support = df[df["support_weight"] > 1e-9].copy()
    baseline = df[df["component_id"].isin(["state_aware", "state_independent"])].copy()
    background = df[(df["support_weight"] <= 1e-9) & (~df["component_id"].isin(["state_aware", "state_independent"]))].copy()
    fig, ax = plt.subplots(figsize=(4.8, 3.2))
    if len(background):
        ax.scatter(background["worst_gap"], background["objective"], s=18, color="#9aa0a6", alpha=0.45, linewidth=0, label="dictionary")
    if len(baseline):
        ax.scatter(baseline["worst_gap"], baseline["objective"], s=34, color="#4c72b0", edgecolor="white", linewidth=0.6, label="baselines")
    if len(support):
        ax.scatter(support["worst_gap"], support["objective"], s=58, color="#c44e52", edgecolor="white", linewidth=0.7, label="certificate support")
    labels = pd.concat([baseline, support], ignore_index=True).drop_duplicates("component_id")
    offsets = [(6, 7), (6, -10), (-36, 10), (-36, -13), (7, 14), (-40, 16)]
    for ix, row in enumerate(labels.itertuples(index=False)):
        weight = float(getattr(row, "support_weight", 0.0))
        if row.component_id == "state_independent":
            label = "state-ind. (%.2f)" % weight if weight > 1e-9 else "state-ind."
        elif row.component_id == "state_aware":
            label = "state-aware"
        elif row.component_id.startswith("priced_target_"):
            label = "p%s (%.2f)" % (row.component_id.rsplit("_", 1)[-1], weight)
        else:
            label = row.component_id if weight <= 1e-9 else f"{row.component_id} ({weight:.2f})"
        ax.annotate(
            label,
            (row.worst_gap, row.objective),
            xytext=offsets[ix % len(offsets)],
            textcoords="offset points",
            fontsize=6.2,
            bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.78, "pad": 0.5},
        )
    ax.axvline(float(summary["tau"]), color="#c44e52", linestyle="--", linewidth=1.0, label="tau")
    ax.set_xlabel("validation worst full-view gap")
    ax.set_ylabel("validation utility")
    ax.set_title("Validation utility-gap frontier")
    ax.legend(frameon=False, loc="lower left", fontsize=6.2)
    save_figure(fig, "figures/utility_gap_frontier")


def plot_latency(latency: pd.DataFrame) -> None:
    configure_matplotlib()
    df = latency[latency["success"]].copy()
    if df.empty:
        return
    summary = df.groupby(["method", "candidate_count", "k", "cache_mode"], as_index=False)["latency_ms"].median()
    k_values = sorted(summary["k"].unique().tolist())
    fig, axes = plt.subplots(1, len(k_values), figsize=(6.9, 3.0), sharey=True)
    if len(k_values) == 1:
        axes = [axes]
    palette = {
        "baseline_state_aware": "#4c72b0",
        "compiled_topk": "#55a868",
        "mixture_dispatch_compiled_topk": "#c44e52",
    }
    names = {
        "baseline_state_aware": "Baseline",
        "compiled_topk": "Compiled",
        "mixture_dispatch_compiled_topk": "Mixture",
    }
    for ax, k in zip(axes, k_values):
        k_sub = summary[summary["k"] == k]
        for (method, cache), sub in k_sub.groupby(["method", "cache_mode"]):
            marker = "o" if cache == "warm" else "s"
            ax.plot(
                sub["candidate_count"],
                sub["latency_ms"],
                marker=marker,
                color=palette.get(method, "#8172b2"),
                linestyle="-" if cache == "warm" else "--",
                label=f"{names.get(method, method)} {cache.replace('connection-', '')}",
            )
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("candidate count")
        ax.set_title(f"k={int(k)}")
    axes[0].set_ylabel("median latency (ms)")
    handles, labels = axes[-1].get_legend_handles_labels()
    fig.legend(handles, labels, frameon=False, fontsize=6.2, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.05))
    fig.suptitle("Top-k SQL latency", y=1.12, fontsize=9)
    save_figure(fig, "figures/latency")


def plot_throughput(concurrency: pd.DataFrame) -> None:
    configure_matplotlib()
    fig, ax = plt.subplots(figsize=(4.6, 3.1))
    ax.bar(concurrency["concurrency"].astype(str), concurrency["throughput_qps"], color="#55a868", alpha=0.9)
    ax.set_xlabel("connections")
    ax.set_ylabel("requests/sec")
    ax.set_title("Compiled Top-k throughput")
    for row in concurrency.itertuples(index=False):
        ax.text(str(row.concurrency), row.throughput_qps, f"{row.failed_requests} fail", ha="center", va="bottom", fontsize=6.5)
    save_figure(fig, "figures/throughput")


def run_mixture_invariant(cfg: dict[str, Any], draws: int = 100_000, resume: bool = False) -> dict[str, Any]:
    out = Path("results/mixture_invariant.json")
    if resume and out.exists():
        return json.loads(out.read_text(encoding="utf-8"))
    rng = np.random.default_rng(int(cfg["seed"]) + 101)
    whole_component = rng.integers(0, 2, size=draws)
    whole_rows = np.column_stack([whole_component, whole_component])
    row_rows = rng.integers(0, 2, size=(draws, 2))
    whole_v = (whole_rows[:, 0] == whole_rows[:, 1]).astype(float)
    row_v = (row_rows[:, 0] == row_rows[:, 1]).astype(float)
    result = {
        "seed": int(cfg["seed"]),
        "draws": int(draws),
        "whole_response_mean": float(whole_v.mean()),
        "row_wise_mean": float(row_v.mean()),
        "difference": float(whole_v.mean() - row_v.mean()),
    }
    result["passed"] = bool(
        abs(result["whole_response_mean"] - 1.0) <= 0.01
        and abs(result["row_wise_mean"] - 0.5) <= 0.02
        and abs(result["difference"]) >= 0.40
    )
    write_json(out, result)
    return result


def run_unit_tests(resume: bool = False) -> dict[str, Any]:
    out = Path("results/unit_tests.json")
    if resume and out.exists():
        return json.loads(out.read_text(encoding="utf-8"))
    start = time.perf_counter()
    proc = subprocess.run([sys.executable, "-m", "pytest", "-q"], text=True, capture_output=True)
    result = {
        "returncode": int(proc.returncode),
        "stdout": proc.stdout[-4000:],
        "stderr": proc.stderr[-4000:],
        "runtime_seconds": time.perf_counter() - start,
        "passed": bool(proc.returncode == 0),
    }
    write_json(out, result)
    return result


def _read(path: str) -> dict[str, Any] | None:
    p = Path(path)
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))


def _check_statuses(cfg: dict[str, Any]) -> dict[str, str]:
    unit = _read("results/unit_tests.json")
    compiler = _read("results/compiler_summary.json")
    cancellation = _read("results/cancellation_summary.json")
    components = _read("results/components.json")
    explicit = _read("results/explicit_lp_comparison.json")
    cert = _read("results/certificate_summary.json")
    mixture = _read("results/mixture_invariant.json")
    bench = _read("results/performance_summary.json")
    tol = float(cfg["optimizer"]["reduced_cost_tolerance"])
    checks = {
        "unit_tests": status(bool(unit and unit.get("passed"))),
        "compiler_parity": status(
            bool(
                compiler
                and compiler.get("sql_python_agreement") == 1.0
                and compiler.get("sql_exhaustive_agreement") == 1.0
            )
        ),
        "cancellation": status(bool(cancellation and cancellation.get("passed"))),
        "column_generation": status(bool(components and components.get("passed") and components.get("final_reduced_cost", 1.0) <= tol)),
        "explicit_lp": status(
            bool(
                explicit
                and explicit.get("passed")
                and explicit.get("absolute_gap", 1.0) <= 1e-7
                and explicit.get("final_reduced_cost", 1.0) <= 1e-8
            )
        ),
        "certificate": status(bool(cert and cert.get("passed"))),
        "mixture_invariant": status(bool(mixture and mixture.get("passed"))),
        "benchmark": status(bool(bench and bench.get("passed"))),
    }
    return checks


def build_report(cfg: dict[str, Any], runtime_seconds: float | None = None) -> dict[str, Any]:
    env = _read("results/environment.json") or collect_environment(Path.cwd(), Path(cfg["database"]["path"]))
    compiler = _read("results/compiler_summary.json")
    cancellation = _read("results/cancellation_summary.json")
    components = _read("results/components.json")
    explicit = _read("results/explicit_lp_comparison.json")
    cert = _read("results/certificate_summary.json")
    mixture = _read("results/mixture_invariant.json")
    bench = _read("results/performance_summary.json")
    checks = _check_statuses(cfg)
    overall = "PASS" if all(v == "PASS" for v in checks.values()) else "FAIL"
    generated_at = time.strftime("%Y-%m-%d %H:%M:%S %z")
    previous = _read("results/final_status.json")
    previous_runtime = previous.get("runtime_seconds") if previous else None
    effective_runtime = float(runtime_seconds or 0.0)
    if effective_runtime < 1.0 and isinstance(previous_runtime, (int, float)) and previous_runtime >= 1.0:
        effective_runtime = float(previous_runtime)
    final_status = {
        "overall": overall,
        "checks": checks,
        "runtime_seconds": effective_runtime,
        "generated_at": generated_at,
    }
    write_json("results/final_status.json", final_status)
    lines = [
        "# SENTRY Executable Validation Report",
        "",
        "## 1. Scope and non-goals",
        "",
        "This executable validation experiment validates the execution and optimization mechanisms on a controlled workload. It does not establish large-scale production practicality, workload generality, or a privacy guarantee beyond the registered audit view.",
        "",
        "## 2. Environment",
        "",
        f"- Status: {overall}",
        f"- OS: {env.get('operating_system')}",
        f"- Python: {str(env.get('python_version')).splitlines()[0] if env.get('python_version') else None}",
        f"- DuckDB: {env.get('duckdb_version')}",
        f"- CPU cores: physical={env.get('physical_cores')}, logical={env.get('logical_cores')}",
        f"- Memory: total={env.get('total_memory')}, available={env.get('available_memory')}",
        f"- Database bytes: {env.get('database_file_size')}",
        "",
        "## 3. Synthetic workload",
        "",
        f"- Development contexts: {cfg['data']['development_contexts']}",
        f"- Validation contexts: {cfg['data']['validation_contexts']}",
        f"- Test contexts: {cfg['data']['test_contexts']}",
        f"- Candidates per context: {cfg['data']['candidates_per_context']}",
        f"- Registered predicates: {', '.join(cfg['predicates'])}",
        "",
        "## 4. Context-cancellation result",
        "",
        f"- Status: {checks['cancellation']}",
        f"- Max absolute global signed gap: {cancellation.get('max_abs_global_signed_gap') if cancellation else None}",
        f"- Max conditional absolute gap: {cancellation.get('max_conditional_abs_gap') if cancellation else None}",
        "",
        "## 5. SQL compiler correctness",
        "",
        f"- Status: {checks['compiler_parity']}",
        f"- Cases: {compiler.get('cases') if compiler else None}",
        f"- SQL/Python agreement: {compiler.get('sql_python_agreement') if compiler else None}",
        f"- SQL/exhaustive agreement: {compiler.get('sql_exhaustive_agreement') if compiler else None}",
        "",
        "## 6. Column-generation versus explicit LP",
        "",
        f"- Column generation status: {checks['column_generation']}",
        f"- CG iterations: {components.get('cg_iterations') if components else None}",
        f"- Final recomputed reduced cost: {components.get('final_reduced_cost') if components else None}",
        f"- Explicit LP status: {checks['explicit_lp']}",
        f"- Objective gap: {explicit.get('absolute_gap') if explicit else None}",
        "",
        "## 7. Held-out full-view certificate",
        "",
        f"- Status: {checks['certificate']}",
        f"- Validation success: {cert.get('validation_success') if cert else None}",
        f"- Fallback: {cert.get('fallback') if cert else None}",
        f"- Test worst registered gap: {cert.get('test_worst_registered_gap') if cert else None}",
        f"- Support size: {cert.get('support_size') if cert else None}",
        "",
        "## 8. Whole-response versus row-wise mixture",
        "",
        f"- Status: {checks['mixture_invariant']}",
        f"- Whole-response mean: {mixture.get('whole_response_mean') if mixture else None}",
        f"- Row-wise mean: {mixture.get('row_wise_mean') if mixture else None}",
        "",
        "## 9. SQL latency and throughput",
        "",
        f"- Status: {checks['benchmark']}",
        f"- Latency records: {bench.get('latency_records') if bench else None}",
        f"- Concurrency records: {bench.get('concurrency_records') if bench else None}",
        "- Cache note: This is connection-cold, not an operating-system cold-cache benchmark.",
        "",
        "## 10. Failures and limitations",
        "",
        f"- Missing latency configs: {bench.get('missing_latency_configs') if bench else None}",
        f"- Missing concurrency configs: {bench.get('missing_concurrency_configs') if bench else None}",
        "- The executable validation checks registered audit views on synthetic data and should not be read as a production scalability or privacy proof.",
        "",
        "## 11. Reproduction commands",
        "",
        "```bash",
        "python -m pip install -e .",
        "python -m pytest -q",
        "python -m sentry_validation.cli all --config configs/validation.yaml",
        "```",
        "",
    ]
    Path("REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    return final_status

