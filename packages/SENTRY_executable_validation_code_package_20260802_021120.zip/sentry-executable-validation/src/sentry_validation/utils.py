from __future__ import annotations

import hashlib
import json
import math
import os
import platform
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import psutil


def project_root() -> Path:
    return Path.cwd()


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_json(path: str | Path, data: dict[str, Any]) -> None:
    p = Path(path)
    ensure_dir(p.parent)
    p.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def read_json(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def position_weights(k: int) -> np.ndarray:
    raw = np.array([1.0 / math.log2(r + 2.0) for r in range(k)], dtype=float)
    return raw / raw.sum()


def stable_hash(values: Iterable[Any]) -> str:
    h = hashlib.sha256()
    for value in values:
        h.update(str(value).encode("utf-8"))
        h.update(b"\x1f")
    return h.hexdigest()


def bool_predicate(name: str, x1: int, x2: int) -> bool:
    if name == "global":
        return True
    if name == "x1_eq_0":
        return x1 == 0
    if name == "x1_eq_1":
        return x1 == 1
    if name == "x2_eq_1":
        return x2 == 1
    if name == "x1_eq_1_and_x2_eq_1":
        return x1 == 1 and x2 == 1
    raise ValueError(f"unknown predicate: {name}")


def active_predicates(predicates: list[str], x1: int, x2: int) -> list[str]:
    return [p for p in predicates if bool_predicate(p, x1, x2)]


@contextmanager
def timed() -> Any:
    start_wall = time.perf_counter()
    start_cpu = time.process_time()
    yield lambda: (time.perf_counter() - start_wall, time.process_time() - start_cpu)


def git_commit_or_none(root: Path) -> str | None:
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=str(root),
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=5,
        ).strip()
        return out or None
    except Exception:
        return None


def collect_environment(root: Path, db_path: Path | None = None) -> dict[str, Any]:
    try:
        import duckdb

        duckdb_version = duckdb.__version__
    except Exception:
        duckdb_version = None
    vm = psutil.virtual_memory()
    cpu_model = platform.processor() or platform.machine() or None
    db_size = db_path.stat().st_size if db_path and db_path.exists() else None
    return {
        "operating_system": platform.platform(),
        "python_version": sys.version,
        "duckdb_version": duckdb_version,
        "cpu_model": cpu_model,
        "physical_cores": psutil.cpu_count(logical=False),
        "logical_cores": psutil.cpu_count(logical=True),
        "total_memory": vm.total,
        "available_memory": vm.available,
        "database_file_size": db_size,
        "git_commit_hash": git_commit_or_none(root),
        "process_id": os.getpid(),
    }


def status(pass_bool: bool) -> str:
    return "PASS" if bool(pass_bool) else "FAIL"

