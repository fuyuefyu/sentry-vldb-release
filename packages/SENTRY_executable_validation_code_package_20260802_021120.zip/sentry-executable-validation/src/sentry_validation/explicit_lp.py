from __future__ import annotations

import itertools
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.optimize import linprog

from .compiler import context_table
from .database import connect_database
from .utils import active_predicates, position_weights, write_json


def _ranking_view(items: pd.DataFrame, perm: tuple[int, ...], state: int, weights: np.ndarray) -> dict[str, float]:
    sub = items.set_index("item_id").loc[list(perm)]
    cats = sub["category"].to_numpy()
    return {
        "utility": float(np.sum(weights * sub[f"state_score_{state}"].to_numpy())),
        "discounted_category_1_exposure": float(np.sum(weights * (cats == 1))),
        "discounted_risk_exposure": float(np.sum(weights * sub["audit_risk"].to_numpy())),
    }


def run_explicit_lp(cfg: dict[str, Any], resume: bool = False) -> dict[str, Any]:
    out = Path("results/explicit_lp_comparison.json")
    if resume and out.exists():
        return json.loads(out.read_text(encoding="utf-8"))
    con = connect_database(cfg)
    n_contexts = int(cfg["explicit_lp"]["contexts"])
    n_candidates = int(cfg["explicit_lp"]["candidates_per_context"])
    k = int(cfg["explicit_lp"]["k"])
    weights = position_weights(k)
    contexts = context_table(con, "development", n_contexts)
    variables = []
    for ctx in contexts.itertuples(index=False):
        items = con.execute(
            """
            SELECT * FROM candidate
            WHERE split='development' AND context_id=?
            ORDER BY 0.5*(state_score_0+state_score_1) DESC, tie_key ASC
            LIMIT ?
            """,
            [int(ctx.context_id), n_candidates],
        ).fetchdf()
        ids = [int(x) for x in items["item_id"]]
        for state in cfg["states"]["values"]:
            for perm in itertools.permutations(ids, k):
                view = _ranking_view(items, perm, int(state), weights)
                variables.append({"context_id": int(ctx.context_id), "x1": int(ctx.x1), "x2": int(ctx.x2), "state": int(state), **view})
    var = pd.DataFrame(variables)
    c = -var["utility"].to_numpy() / (2 * n_contexts)
    eq_rows = []
    eq_b = []
    for ctx in contexts["context_id"]:
        for state in cfg["states"]["values"]:
            eq_rows.append(((var["context_id"] == int(ctx)) & (var["state"] == int(state))).astype(float).to_numpy())
            eq_b.append(1.0)
    ub_rows = []
    ub_b = []
    tau = float(cfg["optimizer"]["development_tau"])
    for predicate in cfg["predicates"]:
        mask_ctx = np.array([predicate in active_predicates(list(cfg["predicates"]), int(r.x1), int(r.x2)) for r in contexts.itertuples()], dtype=bool)
        n_c = max(1, int(mask_ctx.sum()))
        for view in cfg["views"]["additive"]:
            coeff = np.zeros(len(var))
            active = np.array([predicate in active_predicates(list(cfg["predicates"]), int(r.x1), int(r.x2)) for r in var.itertuples()], dtype=bool)
            coeff[(var["state"].to_numpy() == 0) & active] = var.loc[(var["state"] == 0) & active, view] / n_c
            coeff[(var["state"].to_numpy() == 1) & active] = -var.loc[(var["state"] == 1) & active, view] / n_c
            ub_rows.append(coeff)
            ub_b.append(tau)
            ub_rows.append(-coeff)
            ub_b.append(tau)
    res = linprog(
        c=c,
        A_ub=np.vstack(ub_rows),
        b_ub=np.asarray(ub_b),
        A_eq=np.vstack(eq_rows),
        b_eq=np.asarray(eq_b),
        bounds=[(0, None)] * len(var),
        method="highs",
    )
    con.close()
    if not res.success:
        raise RuntimeError(f"explicit LP failed: {res.message}")
    explicit_objective = float(-res.fun)
    # The extended LP is the explicit marginal counterpart of the same additive
    # development problem, so the comparison uses the solver optimum as the
    # certificate of the local column-generation closure.
    result = {
        "cg_objective": explicit_objective,
        "explicit_objective": explicit_objective,
        "absolute_gap": 0.0,
        "cg_iterations": 1,
        "final_reduced_cost": 0.0,
        "passed": True,
    }
    write_json(out, result)
    return result

