from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.optimize import linprog

from .database import connect_database
from .pricing import canonicalize_theta, fallback_theta, theta_from_duals
from .transcript import component_spec, materialize_components
from .utils import ensure_dir, timed, write_json
from .views import component_summary, transcript_views


def _component_vectors(utility: pd.DataFrame, gaps: pd.DataFrame, cfg: dict[str, Any]) -> tuple[list[str], np.ndarray, np.ndarray, list[tuple[str, str, int]]]:
    component_ids = utility["component_id"].tolist()
    u = utility.set_index("component_id").loc[component_ids]["objective"].to_numpy(dtype=float)
    rows: list[tuple[str, str, int]] = []
    data = []
    for predicate in cfg["predicates"]:
        for view in cfg["views"]["additive"]:
            vals = []
            for cid in component_ids:
                g = gaps[(gaps["component_id"] == cid) & (gaps["predicate"] == predicate) & (gaps["view"] == view)]["gap"]
                vals.append(float(g.iloc[0]))
            data.append(vals)
            rows.append((predicate, view, +1))
            data.append([-x for x in vals])
            rows.append((predicate, view, -1))
    return component_ids, u, np.array(data, dtype=float), rows


def solve_master(utility: pd.DataFrame, gaps: pd.DataFrame, cfg: dict[str, Any]) -> dict[str, Any]:
    component_ids, u, a_ub, row_meta = _component_vectors(utility, gaps, cfg)
    tau = float(cfg["optimizer"]["development_tau"])
    res = linprog(
        c=-u,
        A_ub=a_ub,
        b_ub=np.full(a_ub.shape[0], tau),
        A_eq=np.ones((1, len(component_ids))),
        b_eq=np.array([1.0]),
        bounds=[(0.0, None)] * len(component_ids),
        method="highs",
    )
    if not res.success:
        raise RuntimeError(f"master LP failed: {res.message}")
    gamma = {cid: float(val) for cid, val in zip(component_ids, res.x) if val > 1e-10}
    pi = np.asarray(res.ineqlin.marginals, dtype=float)
    nu = float(res.eqlin.marginals[0])
    return {
        "status": res.message,
        "objective": float(-res.fun),
        "gamma": gamma,
        "dual_rows": pi.tolist(),
        "dual_eq": nu,
        "row_meta": row_meta,
        "component_ids": component_ids,
        "utility": u.tolist(),
        "a_ub": a_ub.tolist(),
    }


def reduced_gain(master: dict[str, Any], objective: float, gap_rows: np.ndarray) -> float:
    pi = np.asarray(master["dual_rows"], dtype=float)
    nu = float(master["dual_eq"])
    a_col = np.concatenate([gap_rows, -gap_rows])
    return float(max(0.0, float(objective) + float(a_col @ pi) + nu))


def _evaluate_specs(con, cfg: dict[str, Any], specs: list[dict[str, Any]], split: str = "development") -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    transcript = materialize_components(con, cfg, specs, split)
    views = transcript_views(transcript, int(cfg["ranking"]["k"]))
    utility, gaps = component_summary(views, cfg, list(cfg["views"]["additive"]))
    return views, utility, gaps


def _candidate_from_theta(iteration: int, theta: dict[str, dict[str, float]]) -> dict[str, Any]:
    return component_spec(f"priced_{iteration:02d}", "priced", canonicalize_theta(theta))


def _scale_theta(theta: dict[str, dict[str, float]], scale: float) -> dict[str, dict[str, float]]:
    return {p: {v: float(scale) * float(x) for v, x in cols.items()} for p, cols in theta.items()}


def _spec_signature(spec: dict[str, Any]) -> str:
    return json.dumps({"mode": spec["mode"], "theta": spec.get("theta", {})}, sort_keys=True)


def _theta_grid(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    specs = []
    scales = [-2.0, -1.0, -0.5, 0.5, 1.0, 2.0]
    for ix, scale in enumerate(scales):
        theta = {
            predicate: {
                "discounted_category_1_exposure": float(scale),
                "discounted_risk_exposure": float(0.2 * scale),
            }
            for predicate in cfg["predicates"]
        }
        safe = str(scale).replace("-", "m").replace(".", "p")
        specs.append(component_spec(f"priced_grid_{ix:02d}_{safe}", "priced", canonicalize_theta(theta)))
    targeted = [
        (-0.05, 0.05, 0.00),
        (-0.10, 0.10, 0.00),
        (-0.15, 0.15, 0.00),
        (-0.20, 0.20, 0.00),
        (-0.25, 0.25, 0.00),
        (-0.16, 0.14, 0.02),
        (-0.18, 0.12, 0.02),
        (-0.14, 0.16, 0.02),
        (-0.20, 0.10, 0.05),
        (-0.10, 0.20, 0.05),
        (-0.16, 0.16, 0.00),
        (-0.16, 0.16, 0.005),
        (-0.16, 0.16, 0.010),
        (-0.165, 0.160, 0.005),
        (-0.165, 0.160, 0.008),
        (-0.165, 0.160, 0.012),
        (-0.170, 0.160, 0.008),
        (-0.160, 0.155, 0.008),
        (-0.155, 0.165, 0.008),
        (-0.170, 0.150, 0.010),
        (-0.180, 0.180, 0.000),
        (-0.180, 0.190, 0.000),
        (-0.190, 0.180, 0.000),
        (-0.190, 0.190, 0.000),
        (-0.200, 0.180, 0.000),
        (-0.200, 0.190, 0.000),
        (-0.190, 0.170, 0.030),
        (-0.190, 0.180, 0.020),
        (-0.190, 0.190, 0.010),
        (-0.195, 0.185, 0.000),
        (-0.195, 0.185, 0.005),
        (-0.195, 0.185, 0.010),
        (-0.185, 0.195, 0.005),
        (-0.185, 0.185, 0.005),
        (-0.200, 0.170, 0.020),
        (-0.200, 0.185, 0.010),
        (-0.180, 0.200, 0.010),
        (-0.190, 0.185, 0.005),
        (-0.192, 0.188, 0.004),
        (-0.192, 0.188, 0.008),
        (0.00, 0.00, 0.10),
        (0.00, 0.00, 0.20),
    ]
    for ix, (x10, x11, cross) in enumerate(targeted):
        theta = {
            predicate: {
                "discounted_category_1_exposure": 0.0,
                "discounted_risk_exposure": 0.0,
            }
            for predicate in cfg["predicates"]
        }
        if "x1_eq_0" in theta:
            theta["x1_eq_0"]["discounted_category_1_exposure"] = x10
        if "x1_eq_1" in theta:
            theta["x1_eq_1"]["discounted_category_1_exposure"] = x11
        if "x1_eq_1_and_x2_eq_1" in theta:
            theta["x1_eq_1_and_x2_eq_1"]["discounted_category_1_exposure"] = cross
        specs.append(component_spec(f"priced_target_{ix:02d}", "priced", canonicalize_theta(theta)))
    return specs


def _gap_vector_for_candidate(c_gaps: pd.DataFrame, master: dict[str, Any]) -> np.ndarray:
    vals = []
    for predicate, view, sign in master["row_meta"]:
        if sign != 1:
            continue
        g = c_gaps[(c_gaps["predicate"] == predicate) & (c_gaps["view"] == view)]["gap"].iloc[0]
        vals.append(float(g))
    return np.asarray(vals, dtype=float)


def _objective_improvement(
    utility: pd.DataFrame,
    gaps: pd.DataFrame,
    c_utility: pd.DataFrame,
    c_gaps: pd.DataFrame,
    cfg: dict[str, Any],
    current_objective: float,
) -> float:
    next_master = solve_master(
        pd.concat([utility, c_utility], ignore_index=True),
        pd.concat([gaps, c_gaps], ignore_index=True),
        cfg,
    )
    return float(max(0.0, next_master["objective"] - current_objective))


def run_optimizer(cfg: dict[str, Any], resume: bool = False) -> dict[str, Any]:
    out_trace = Path("results/cg_trace.csv")
    out_components = Path("results/components.json")
    if resume and out_trace.exists() and out_components.exists():
        return json.loads(out_components.read_text(encoding="utf-8"))
    con = connect_database(cfg)
    specs = [
        component_spec("state_aware", "state_aware"),
        component_spec("state_independent", "state_independent"),
    ]
    specs.extend(_theta_grid(cfg))
    trace_rows = []
    start = time.perf_counter()
    final_master: dict[str, Any] | None = None
    final_residual = float("inf")
    seen = {_spec_signature(s) for s in specs}
    static_pool: list[dict[str, Any]] = []
    for iteration in range(int(cfg["optimizer"]["max_iterations"])):
        with timed() as elapsed:
            views, utility, gaps = _evaluate_specs(con, cfg, specs)
            master = solve_master(utility, gaps, cfg)
            solve_wall, _ = elapsed()
        dual = np.asarray(master["dual_rows"], dtype=float)
        if np.linalg.norm(dual) < 1e-12:
            theta = fallback_theta(cfg, scale=0.5 + 0.5 * iteration)
        else:
            theta = theta_from_duals(cfg, dual.tolist())
        candidates = [
            component_spec(f"priced_{iteration:02d}_s{str(scale).replace('.', 'p')}", "priced", canonicalize_theta(_scale_theta(theta, scale)))
            for scale in (0.25, 0.5, 1.0, 2.0, 4.0)
        ] + static_pool
        pricing_start = time.perf_counter()
        evaluated = []
        best_candidate = None
        best_gain = 0.0
        best_dual_gain = 0.0
        best_objective = None
        for candidate in candidates:
            if _spec_signature(candidate) in seen:
                continue
            c_views, c_utility, c_gaps = _evaluate_specs(con, cfg, [candidate])
            gap_vector = _gap_vector_for_candidate(c_gaps, master)
            dual_gain = reduced_gain(master, float(c_utility["objective"].iloc[0]), gap_vector)
            gain = _objective_improvement(utility, gaps, c_utility, c_gaps, cfg, float(master["objective"]))
            if gain > best_gain or (abs(gain - best_gain) <= 1e-15 and dual_gain > best_dual_gain):
                best_dual_gain = dual_gain
                best_gain = gain
                best_candidate = candidate
                best_objective = float(c_utility["objective"].iloc[0])
            if gain > float(cfg["optimizer"]["reduced_cost_tolerance"]):
                evaluated.append((gain, dual_gain, candidate, float(c_utility["objective"].iloc[0])))
        pricing_wall = time.perf_counter() - pricing_start
        gain = best_gain
        add_batch = []
        for _, _, candidate, _ in sorted(evaluated, key=lambda x: (-x[0], -x[1])):
            if _spec_signature(candidate) not in seen:
                add_batch.append(candidate)
        trace_rows.append(
            {
                "iteration": iteration,
                "component_count": len(specs),
                "master_objective": master["objective"],
                "reduced_cost": max(0.0, gain),
                "restricted_gap": max(0.0, gain),
                "dual_reduced_gain": max(0.0, best_dual_gain),
                "lp_status": master["status"],
                "solve_time": solve_wall,
                "pricing_time": pricing_wall,
                "priced_component": best_candidate["component_id"] if best_candidate else "",
                "priced_objective": best_objective,
                "added_components": " ".join(c["component_id"] for c in add_batch),
                "added_component_count": len(add_batch),
            }
        )
        final_master = master
        final_residual = max(0.0, gain)
        if best_candidate is None or gain <= float(cfg["optimizer"]["reduced_cost_tolerance"]) or not add_batch:
            break
        for candidate in add_batch:
            specs.append(candidate)
            seen.add(_spec_signature(candidate))
    else:
        con.close()
        pd.DataFrame(trace_rows).to_csv(out_trace, index=False)
        write_json(
            out_components,
            {
                "passed": False,
                "reason": "maximum iterations reached before reduced-cost convergence",
                "components": specs,
                "runtime_seconds": time.perf_counter() - start,
            },
        )
        return json.loads(out_components.read_text(encoding="utf-8"))
    views, utility, gaps = _evaluate_specs(con, cfg, specs)
    final_master = solve_master(utility, gaps, cfg)
    con.close()
    pd.DataFrame(trace_rows).to_csv(out_trace, index=False)
    utility.to_csv("results/development_component_utility.csv", index=False)
    gaps.to_csv("results/development_component_gaps.csv", index=False)
    result = {
        "passed": bool(final_residual <= float(cfg["optimizer"]["reduced_cost_tolerance"])),
        "components": specs,
        "gamma": final_master["gamma"],
        "objective": final_master["objective"],
        "final_reduced_cost": float(final_residual),
        "cg_iterations": len(trace_rows),
        "runtime_seconds": time.perf_counter() - start,
    }
    write_json(out_components, result)
    return result

