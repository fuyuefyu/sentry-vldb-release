from __future__ import annotations

from typing import Any

import pandas as pd

from .compiler import compiled_topk_sql, context_table, eta_from_theta, score_expression, slice_counts


def component_spec(component_id: str, mode: str, theta: dict[str, dict[str, float]] | None = None) -> dict[str, Any]:
    return {"component_id": component_id, "mode": mode, "theta": theta or {}}


def score_for_context(
    cfg: dict[str, Any],
    spec: dict[str, Any],
    split_counts: dict[str, int],
    x1: int,
    x2: int,
    state: int,
) -> tuple[str, float, float]:
    mode = spec["mode"]
    if mode == "state_aware":
        return "state", 0.0, 0.0
    if mode == "state_independent":
        return "state_independent", 0.0, 0.0
    if mode == "priced":
        eta_cat, eta_risk = eta_from_theta(cfg, split_counts, spec["theta"], x1, x2, state)
        return "state", eta_cat, eta_risk
    raise ValueError(f"unknown component mode: {mode}")


def materialize_component(
    con,
    cfg: dict[str, Any],
    spec: dict[str, Any],
    split: str,
    limit_contexts: int | None = None,
    k_override: int | None = None,
) -> pd.DataFrame:
    k = int(k_override or cfg["ranking"]["k"])
    if limit_contexts is None:
        return _materialize_component_batch(con, cfg, spec, split, k)
    contexts = context_table(con, split, limit_contexts)
    split_counts = slice_counts(con, cfg, "development")
    out = []
    for row in contexts.itertuples(index=False):
        for state in cfg["states"]["values"]:
            score_mode, eta_cat, eta_risk = score_for_context(cfg, spec, split_counts, int(row.x1), int(row.x2), int(state))
            df = compiled_topk_sql(
                con,
                split=split,
                context_id=int(row.context_id),
                state=int(state),
                k=k,
                eta_category=eta_cat,
                eta_risk=eta_risk,
                component_id=spec["component_id"],
                score_mode=score_mode,
            )
            df.insert(0, "split", split)
            out.append(df)
    return pd.concat(out, ignore_index=True) if out else pd.DataFrame()


def _eta_case_expression(cfg: dict[str, Any], spec: dict[str, Any], split_counts: dict[str, int], state: int, which: str) -> str:
    clauses = []
    for x1 in (0, 1):
        for x2 in (0, 1):
            eta_cat, eta_risk = eta_from_theta(cfg, split_counts, spec["theta"], x1, x2, state)
            value = eta_cat if which == "category" else eta_risk
            clauses.append(f"WHEN x1 = {x1} AND x2 = {x2} THEN {float(value):.17g}")
    return "CASE " + " ".join(clauses) + " ELSE 0.0 END"


def _materialize_component_batch(con, cfg: dict[str, Any], spec: dict[str, Any], split: str, k: int) -> pd.DataFrame:
    split_counts = slice_counts(con, cfg, "development")
    frames = []
    for state in cfg["states"]["values"]:
        score_mode, _, _ = score_for_context(cfg, spec, split_counts, 0, 0, int(state))
        state_expr = score_expression(int(state), score_mode)
        if spec["mode"] == "priced":
            eta_category = _eta_case_expression(cfg, spec, split_counts, int(state), "category")
            eta_risk = _eta_case_expression(cfg, spec, split_counts, int(state), "risk")
        else:
            eta_category = "0.0"
            eta_risk = "0.0"
        sql = f"""
            SELECT
                split,
                context_id,
                {int(state)}::INTEGER AS state,
                ?::VARCHAR AS component_id,
                rank,
                x1,
                x2,
                item_id,
                category,
                audit_category_1,
                audit_risk,
                state_score_0,
                state_score_1,
                adjusted_score,
                {str(score_mode == "state_independent").lower()}::BOOLEAN AS fallback,
                {"state_score_0" if int(state) == 0 else "state_score_1"} AS utility_score
            FROM (
                SELECT
                    split,
                    context_id,
                    x1,
                    x2,
                    item_id,
                    category,
                    audit_category_1,
                    audit_risk,
                    state_score_0,
                    state_score_1,
                    ({state_expr} - ({eta_category}) * audit_category_1 - ({eta_risk}) * audit_risk) AS adjusted_score,
                    ROW_NUMBER() OVER (
                        PARTITION BY context_id
                        ORDER BY ({state_expr} - ({eta_category}) * audit_category_1 - ({eta_risk}) * audit_risk) DESC, tie_key ASC
                    ) AS rank
                FROM candidate
                WHERE split = ?
            )
            WHERE rank <= ?
            ORDER BY context_id, rank
        """
        frames.append(con.execute(sql, [spec["component_id"], split, int(k)]).fetchdf())
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def materialize_components(con, cfg: dict[str, Any], specs: list[dict[str, Any]], split: str, limit_contexts: int | None = None, k_override: int | None = None) -> pd.DataFrame:
    return pd.concat(
        [materialize_component(con, cfg, spec, split, limit_contexts=limit_contexts, k_override=k_override) for spec in specs],
        ignore_index=True,
    )

