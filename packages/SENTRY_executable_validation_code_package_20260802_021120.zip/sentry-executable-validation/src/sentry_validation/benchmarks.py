from __future__ import annotations

import concurrent.futures
import json
import math
import time
from pathlib import Path
from typing import Any

import duckdb
import numpy as np
import pandas as pd
import psutil

from .config import prepare_paths
from .database import connect_database
from .reporting import plot_latency, plot_throughput
from .utils import write_json


METHODS = ["baseline_state_aware", "compiled_topk", "mixture_dispatch_compiled_topk"]


def _create_benchmark_table(con: duckdb.DuckDBPyConnection, n: int) -> None:
    con.execute("DROP TABLE IF EXISTS benchmark_candidate")
    con.execute(
        """
        CREATE TABLE benchmark_candidate AS
        SELECT
            'benchmark'::VARCHAR AS split,
            0::BIGINT AS context_id,
            (i % 2)::INTEGER AS x1,
            ((i / 2)::BIGINT % 2)::INTEGER AS x2,
            i::BIGINT AS item_id,
            (i % 4)::INTEGER AS category,
            sin(i * 0.017)::DOUBLE AS base_score,
            (sin(i * 0.017) - 0.35 * CASE WHEN (i % 4) = 1 THEN 1.0 ELSE -0.35 END - 0.08 * abs(cos(i * 0.011)))::DOUBLE AS state_score_0,
            (sin(i * 0.017) + 0.35 * CASE WHEN (i % 4) = 1 THEN 1.0 ELSE -0.35 END + 0.08 * abs(cos(i * 0.011)))::DOUBLE AS state_score_1,
            CASE WHEN (i % 4) = 1 THEN 1.0 ELSE 0.0 END::DOUBLE AS audit_category_1,
            abs(cos(i * 0.011))::DOUBLE AS audit_risk,
            i::BIGINT AS tie_key
        FROM range(?) AS t(i)
        """
        ,
        [int(n)],
    )
    con.execute("ANALYZE benchmark_candidate")


def _query_sql(method: str, state: int, k: int) -> tuple[str, list[Any]]:
    state_col = "state_score_0" if int(state) == 0 else "state_score_1"
    if method == "baseline_state_aware":
        return (
            f"""
            SELECT item_id, category, {state_col} AS score
            FROM benchmark_candidate
            ORDER BY {state_col} DESC, tie_key ASC
            LIMIT ?
            """,
            [int(k)],
        )
    if method == "compiled_topk":
        return (
            f"""
            SELECT item_id, category, ({state_col} - ? * audit_category_1 - ? * audit_risk) AS score
            FROM benchmark_candidate
            ORDER BY score DESC, tie_key ASC
            LIMIT ?
            """,
            [0.3, 0.06, int(k)],
        )
    if method == "mixture_dispatch_compiled_topk":
        # Deterministic public dispatch for reproducibility: even states use the
        # compiled score, odd states use the state-independent fallback score.
        score_expr = (
            f"({state_col} - ? * audit_category_1 - ? * audit_risk)"
            if int(state) == 0
            else "0.5 * (state_score_0 + state_score_1)"
        )
        params = [0.3, 0.06, int(k)] if int(state) == 0 else [int(k)]
        return (
            f"""
            SELECT item_id, category, {score_expr} AS score
            FROM benchmark_candidate
            ORDER BY score DESC, tie_key ASC
            LIMIT ?
            """,
            params,
        )
    raise ValueError(f"unknown benchmark method: {method}")


def _run_query(con: duckdb.DuckDBPyConnection, method: str, state: int, k: int) -> pd.DataFrame:
    sql, params = _query_sql(method, state, k)
    return con.execute(sql, params).fetchdf()


def _checksum(df: pd.DataFrame) -> int:
    total = 0
    for rank, item_id in enumerate(df["item_id"].tolist(), start=1):
        total = (total + rank * int(item_id)) % 2_147_483_647
    return int(total)


def _latency_record(
    cfg: dict[str, Any],
    method: str,
    candidate_count: int,
    k: int,
    cache_mode: str,
    run_id: int,
) -> dict[str, Any]:
    proc = psutil.Process()
    rss_before = proc.memory_info().rss
    success = True
    error = ""
    returned = 0
    checksum = None
    start_wall = time.perf_counter()
    start_cpu = time.process_time()
    con = None
    try:
        con = connect_database(cfg, read_only=True) if cache_mode == "connection-cold" else None
        active_con = con
        if active_con is None:
            raise RuntimeError("warm connection must be supplied by caller")
        df = _run_query(active_con, method, state=run_id % 2, k=k)
        returned = int(len(df))
        checksum = _checksum(df)
    except Exception as exc:
        success = False
        error = str(exc)
    finally:
        if con is not None:
            con.close()
    latency_ms = (time.perf_counter() - start_wall) * 1000.0
    cpu_ms = (time.process_time() - start_cpu) * 1000.0
    rss_after = proc.memory_info().rss
    return {
        "seed": int(cfg["seed"]),
        "method": method,
        "candidate_count": int(candidate_count),
        "k": int(k),
        "cache_mode": cache_mode,
        "run_id": int(run_id),
        "latency_ms": latency_ms,
        "cpu_ms": cpu_ms,
        "rss_mb": rss_after / (1024 * 1024),
        "rss_delta_mb": (rss_after - rss_before) / (1024 * 1024),
        "returned_row_count": returned,
        "ranking_checksum": checksum,
        "success": bool(success),
        "error": error,
    }


def _warm_latency_records(
    cfg: dict[str, Any],
    con: duckdb.DuckDBPyConnection,
    method: str,
    candidate_count: int,
    k: int,
) -> list[dict[str, Any]]:
    warmups = int(cfg["benchmark"]["warmup_runs"])
    runs = int(cfg["benchmark"]["measured_runs"])
    for i in range(warmups):
        try:
            _run_query(con, method, state=i % 2, k=k)
        except Exception:
            break
    records = []
    proc = psutil.Process()
    for run_id in range(runs):
        rss_before = proc.memory_info().rss
        start_wall = time.perf_counter()
        start_cpu = time.process_time()
        success = True
        error = ""
        returned = 0
        checksum = None
        try:
            df = _run_query(con, method, state=run_id % 2, k=k)
            returned = int(len(df))
            checksum = _checksum(df)
        except Exception as exc:
            success = False
            error = str(exc)
        latency_ms = (time.perf_counter() - start_wall) * 1000.0
        cpu_ms = (time.process_time() - start_cpu) * 1000.0
        rss_after = proc.memory_info().rss
        records.append(
            {
                "seed": int(cfg["seed"]),
                "method": method,
                "candidate_count": int(candidate_count),
                "k": int(k),
                "cache_mode": "warm",
                "run_id": run_id,
                "latency_ms": latency_ms,
                "cpu_ms": cpu_ms,
                "rss_mb": rss_after / (1024 * 1024),
                "rss_delta_mb": (rss_after - rss_before) / (1024 * 1024),
                "returned_row_count": returned,
                "ranking_checksum": checksum,
                "success": bool(success),
                "error": error,
            }
        )
    return records


def _save_explain(con: duckdb.DuckDBPyConnection) -> None:
    Path("artifacts/explain").mkdir(parents=True, exist_ok=True)
    for method, name in [("baseline_state_aware", "baseline"), ("compiled_topk", "compiled")]:
        sql, params = _query_sql(method, state=0, k=10)
        explain_df = con.execute("EXPLAIN ANALYZE " + sql, params).fetchdf()
        Path(f"artifacts/explain/{name}.txt").write_text(explain_df.to_string(index=False), encoding="utf-8")


def _concurrency_task(cfg: dict[str, Any], method: str, k: int, request_id: int) -> dict[str, Any]:
    start = time.perf_counter()
    success = True
    error = ""
    try:
        con = connect_database(cfg, read_only=True)
        try:
            df = _run_query(con, method, state=request_id % 2, k=k)
            returned = len(df)
        finally:
            con.close()
    except Exception as exc:
        success = False
        error = str(exc)
        returned = 0
    return {
        "success": bool(success),
        "error": error,
        "latency_ms": (time.perf_counter() - start) * 1000.0,
        "returned": int(returned),
    }


def _run_concurrency(cfg: dict[str, Any], candidate_count: int, k: int) -> list[dict[str, Any]]:
    rows = []
    method = "compiled_topk"
    requests = int(cfg["benchmark"]["requests_per_concurrency_level"])
    for level in cfg["benchmark"]["concurrency"]:
        start = time.perf_counter()
        task_results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=int(level)) as pool:
            futures = [pool.submit(_concurrency_task, cfg, method, k, i) for i in range(requests)]
            for future in concurrent.futures.as_completed(futures, timeout=float(cfg["benchmark"]["query_timeout_seconds"])):
                task_results.append(future.result())
        total_wall = time.perf_counter() - start
        lat = np.array([r["latency_ms"] for r in task_results], dtype=float)
        errors = [r["error"] for r in task_results if r["error"]]
        rows.append(
            {
                "seed": int(cfg["seed"]),
                "method": method,
                "candidate_count": int(candidate_count),
                "k": int(k),
                "concurrency": int(level),
                "total_requests": requests,
                "successful_requests": int(sum(r["success"] for r in task_results)),
                "failed_requests": int(requests - sum(r["success"] for r in task_results)),
                "throughput_qps": float(len(task_results) / total_wall) if total_wall > 0 else math.nan,
                "p50_ms": float(np.percentile(lat, 50)) if len(lat) else math.nan,
                "p95_ms": float(np.percentile(lat, 95)) if len(lat) else math.nan,
                "p99_ms": float(np.percentile(lat, 99)) if len(lat) else math.nan,
                "error": "; ".join(sorted(set(errors)))[:500],
            }
        )
    return rows


def _summarize_latency(latency: pd.DataFrame, cfg: dict[str, Any]) -> dict[str, Any]:
    expected = []
    for method in METHODS:
        for n in cfg["benchmark"]["candidate_counts"]:
            for k in cfg["benchmark"]["k_values"]:
                for cache in ["connection-cold", "warm"]:
                    expected.append((method, int(n), int(k), cache))
    observed = {
        (r.method, int(r.candidate_count), int(r.k), r.cache_mode)
        for r in latency.itertuples()
    }
    missing = [f"{m}/{n}/k{k}/{cache}" for m, n, k, cache in expected if (m, n, k, cache) not in observed]
    ratios = []
    ok = latency[latency["success"]]
    for (n, k, cache), sub in ok.groupby(["candidate_count", "k", "cache_mode"]):
        base = sub[sub["method"] == "baseline_state_aware"]["latency_ms"]
        comp = sub[sub["method"] == "compiled_topk"]["latency_ms"]
        if len(base) and len(comp):
            ratios.append(
                {
                    "candidate_count": int(n),
                    "k": int(k),
                    "cache_mode": cache,
                    "compiled_to_baseline_p50_ratio": float(np.median(comp) / max(np.median(base), 1e-12)),
                }
            )
    return {"missing_latency_configs": missing, "compiled_baseline_ratios": ratios}


def run_benchmark(cfg: dict[str, Any], resume: bool = False) -> dict[str, Any]:
    if resume and Path("results/performance_summary.json").exists():
        return json.loads(Path("results/performance_summary.json").read_text(encoding="utf-8"))
    prepare_paths(cfg)
    max_seconds = float(cfg["benchmark"].get("max_seconds", 600))
    started = time.perf_counter()
    latency_rows: list[dict[str, Any]] = []
    con = connect_database(cfg)
    try:
        for candidate_count in cfg["benchmark"]["candidate_counts"]:
            _create_benchmark_table(con, int(candidate_count))
            if int(candidate_count) == max(int(x) for x in cfg["benchmark"]["candidate_counts"]):
                _save_explain(con)
            con.close()
            for method in METHODS:
                for k in cfg["benchmark"]["k_values"]:
                    warm_con = connect_database(cfg)
                    try:
                        latency_rows.extend(_warm_latency_records(cfg, warm_con, method, int(candidate_count), int(k)))
                    finally:
                        warm_con.close()
                    for run_id in range(int(cfg["benchmark"]["measured_runs"])):
                        latency_rows.append(_latency_record(cfg, method, int(candidate_count), int(k), "connection-cold", run_id))
                    if time.perf_counter() - started > max_seconds:
                        break
                if time.perf_counter() - started > max_seconds:
                    break
            con = connect_database(cfg)
            if time.perf_counter() - started > max_seconds:
                break
        if not con:
            con = connect_database(cfg)
        max_n = max(int(x) for x in cfg["benchmark"]["candidate_counts"])
        _create_benchmark_table(con, max_n)
        con.close()
    finally:
        try:
            con.close()
        except Exception:
            pass
    latency = pd.DataFrame(latency_rows)
    latency.to_csv("results/latency.csv", index=False)
    k0 = int(cfg["benchmark"]["k_values"][0])
    concurrency_rows = _run_concurrency(cfg, max(int(x) for x in cfg["benchmark"]["candidate_counts"]), k0)
    concurrency = pd.DataFrame(concurrency_rows)
    concurrency.to_csv("results/concurrency.csv", index=False)
    summary = _summarize_latency(latency, cfg)
    expected_concurrency = {int(x) for x in cfg["benchmark"]["concurrency"]}
    observed_concurrency = set(int(x) for x in concurrency["concurrency"].tolist()) if len(concurrency) else set()
    summary.update(
        {
            "connection_cold_note": "This is connection-cold, not an operating-system cold-cache benchmark.",
            "missing_concurrency_configs": sorted(expected_concurrency - observed_concurrency),
            "latency_records": int(len(latency)),
            "concurrency_records": int(len(concurrency)),
            "benchmark_runtime_seconds": time.perf_counter() - started,
            "passed": bool(not summary["missing_latency_configs"] and not (expected_concurrency - observed_concurrency)),
        }
    )
    write_json("results/performance_summary.json", summary)
    if len(latency):
        plot_latency(latency)
    if len(concurrency):
        plot_throughput(concurrency)
    return summary

