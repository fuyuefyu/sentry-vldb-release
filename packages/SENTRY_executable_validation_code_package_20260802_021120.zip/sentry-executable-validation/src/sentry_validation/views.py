from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from .utils import active_predicates, position_weights


ADDITIVE_COLUMNS = ["discounted_category_1_exposure", "discounted_risk_exposure"]
FULL_COLUMNS = ADDITIVE_COLUMNS + ["top1_category_1", "max_category_concentration"]


def transcript_views(transcript: pd.DataFrame, k: int) -> pd.DataFrame:
    weights = position_weights(k)
    rows = []
    keys = ["component_id", "split", "context_id", "state", "x1", "x2"]
    for key, grp in transcript.groupby(keys, sort=False):
        g = grp.sort_values("rank").copy()
        local_w = weights[: len(g)]
        cats = g["category"].to_numpy()
        rows.append(
            {
                "component_id": key[0],
                "split": key[1],
                "context_id": int(key[2]),
                "state": int(key[3]),
                "x1": int(key[4]),
                "x2": int(key[5]),
                "utility": float(np.sum(local_w * g["utility_score"].to_numpy())),
                "discounted_category_1_exposure": float(np.sum(local_w * (cats == 1))),
                "discounted_risk_exposure": float(np.sum(local_w * g["audit_risk"].to_numpy())),
                "top1_category_1": float(cats[0] == 1),
                "max_category_concentration": float(pd.Series(cats).value_counts().max() / len(cats)),
            }
        )
    return pd.DataFrame(rows)


def gap_table(views: pd.DataFrame, cfg: dict[str, Any], columns: list[str]) -> pd.DataFrame:
    rows = []
    for component_id, cdf in views.groupby("component_id"):
        for predicate in cfg["predicates"]:
            mask = [predicate in active_predicates(list(cfg["predicates"]), int(r.x1), int(r.x2)) for r in cdf.itertuples()]
            sdf = cdf.loc[mask]
            for col in columns:
                state0 = sdf[sdf["state"] == 0][col]
                state1 = sdf[sdf["state"] == 1][col]
                gap = float(state0.mean() - state1.mean()) if len(state0) and len(state1) else float("nan")
                rows.append(
                    {
                        "component_id": component_id,
                        "predicate": predicate,
                        "view": col,
                        "n_c": int(len(sdf[sdf["state"] == 0])),
                        "gap": gap,
                        "abs_gap": abs(gap),
                    }
                )
    return pd.DataFrame(rows)


def component_summary(views: pd.DataFrame, cfg: dict[str, Any], columns: list[str]) -> tuple[pd.DataFrame, pd.DataFrame]:
    gaps = gap_table(views, cfg, columns)
    utility = views.groupby("component_id", as_index=False)["utility"].mean().rename(columns={"utility": "objective"})
    return utility, gaps


def worst_gap(views: pd.DataFrame, cfg: dict[str, Any], columns: list[str]) -> float:
    gaps = gap_table(views, cfg, columns)
    return float(gaps["abs_gap"].max())

