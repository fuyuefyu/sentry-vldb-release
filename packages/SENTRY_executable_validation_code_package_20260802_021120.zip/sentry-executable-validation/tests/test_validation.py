import pandas as pd

from sentry_validation.validation_lp import mixture_views


def test_mixture_views_uses_whole_component_weights():
    views = pd.DataFrame(
        {
            "component_id": ["a", "b"],
            "split": ["test", "test"],
            "context_id": [1, 1],
            "state": [0, 0],
            "x1": [0, 0],
            "x2": [0, 0],
            "utility": [1.0, 0.0],
            "discounted_category_1_exposure": [0.2, 0.8],
            "discounted_risk_exposure": [0.1, 0.3],
            "top1_category_1": [0.0, 1.0],
            "max_category_concentration": [0.5, 1.0],
        }
    )
    out = mixture_views(views, {"a": 0.25, "b": 0.75})
    assert abs(float(out["utility"].iloc[0]) - 0.25) <= 1e-12
    assert abs(float(out["top1_category_1"].iloc[0]) - 0.75) <= 1e-12

