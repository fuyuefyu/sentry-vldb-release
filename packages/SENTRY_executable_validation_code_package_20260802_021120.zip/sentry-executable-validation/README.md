# SENTRY Executable Validation

This repository is a DuckDB-backed executable validation package for the SENTRY
execution and optimization mechanisms on a controlled workload. It provides the
standalone executable witness summarized in the manuscript
certificate-disclosure table.

## Setup

Python 3.11 or newer is required. On Windows, use `py -3.14 -m ...` or another
3.11+ interpreter if `python` points to an older installation.

Install the package from the repository root:

```bash
python -m pip install -e .
```

## Smoke Reproduction

The smoke run exercises the full validation path at a smaller scale:

```bash
python -m pytest -q
python -m sentry_validation.cli all --config configs/smoke.yaml
```

Expected status is written to `results/final_status.json`. A successful run has
`"overall": "PASS"` and individual `PASS` entries for compiler parity,
cancellation, column generation, explicit-LP comparison, certificate checks,
mixture invariants, benchmark checks, and unit tests.

## Full Validation Run

Use the full configuration for the standalone executable witness:

```bash
python -m sentry_validation.cli all --config configs/validation.yaml
```

## Code Map

- `src/sentry_validation/data.py` builds the controlled candidate table and
  registered audit-view columns.
- `src/sentry_validation/compiler.py` compiles ranked SQL plans and parity
  checks.
- `src/sentry_validation/master_lp.py`, `pricing.py`, `explicit_lp.py`, and
  `validation_lp.py` implement the optimization and certificate checks.
- `src/sentry_validation/views.py` and `database.py` manage DuckDB view
  materialization and query execution.
- `src/sentry_validation/benchmarks.py` records latency/resource measurements.
- `src/sentry_validation/reporting.py` writes the validation reports and figure
  outputs.
- `src/sentry_validation/cli.py` orchestrates the end-to-end run.

## Outputs

The run writes:

- numeric outputs to `results/`;
- figure outputs to `figures/`;
- the DuckDB database to `artifacts/`;
- representative `EXPLAIN ANALYZE` plans to `artifacts/explain/`.

This package validates the execution and optimization mechanisms on a controlled
workload. It does not claim large-scale production deployment, workload
generality, or a privacy guarantee beyond the registered audit view.

