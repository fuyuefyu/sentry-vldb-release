# SENTRY Executable Validation Report

## 1. Scope and non-goals

This executable validation experiment validates the execution and optimization mechanisms on a controlled workload. It does not establish large-scale production practicality, workload generality, or a privacy guarantee beyond the registered audit view.

## 2. Environment

- Status: PASS
- OS: Windows-11-10.0.26200-SP0
- Python: 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]
- DuckDB: 1.5.5
- CPU cores: physical=24, logical=32
- Memory: total=33917186048, available=14030344192
- Database bytes: 1060864

## 3. Synthetic workload

- Development contexts: 40
- Validation contexts: 120
- Test contexts: 240
- Candidates per context: 30
- Registered predicates: global, x1_eq_0, x1_eq_1, x2_eq_1, x1_eq_1_and_x2_eq_1

## 4. Context-cancellation result

- Status: PASS
- Max absolute global signed gap: 0.0
- Max conditional absolute gap: 0.6719129124268807

## 5. SQL compiler correctness

- Status: PASS
- Cases: 1000
- SQL/Python agreement: 1.0
- SQL/exhaustive agreement: 1.0

## 6. Column-generation versus explicit LP

- Column generation status: PASS
- CG iterations: 7
- Final recomputed reduced cost: 0.0
- Explicit LP status: PASS
- Objective gap: 0.0

## 7. Held-out full-view certificate

- Status: PASS
- Validation success: False
- Fallback: True
- Test worst registered gap: 0.0
- Support size: 1

## 8. Whole-response versus row-wise mixture

- Status: PASS
- Whole-response mean: 1.0
- Row-wise mean: 0.50086

## 9. SQL latency and throughput

- Status: PASS
- Latency records: 36
- Concurrency records: 2
- Cache note: This is connection-cold, not an operating-system cold-cache benchmark.

## 10. Failures and limitations

- Missing latency configs: []
- Missing concurrency configs: []
- The executable validation checks registered audit views on synthetic data and should not be read as a production scalability or privacy proof.

## 11. Reproduction commands

```bash
python -m pip install -e .
python -m pytest -q
python -m sentry_validation.cli all --config configs/validation.yaml
```
