from __future__ import annotations

import argparse
from pathlib import Path

from common import ROOT


EXTENSIONS = [".aux", ".bbl", ".blg", ".log", ".out", ".toc", ".fls", ".fdb_latexmk"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--jobname", required=True)
    args = parser.parse_args()
    removed = 0
    for ext in EXTENSIONS:
        path = ROOT / f"{args.jobname}{ext}"
        if path.exists():
            path.unlink()
            removed += 1
    print(f"removed {removed} latex aux files")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
