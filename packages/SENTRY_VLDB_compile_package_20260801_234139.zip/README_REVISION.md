# SENTRY revision package

The revised manuscript source is `main_revised_vldb.tex`; the integrated build
target is `main_revised_vldb_filled.tex`.  The manuscript now uses regenerated
experiment values and regenerated RQ figures.  The proof text for theorem-like
results is deferred to the appendix.

## Current build commands

```bash
make draft        # compile the current manuscript source
make check        # run non-final checks, experiments, figures, artifact checks
make release-staging
make strict       # final submission gate after the public artifact URL exists
```

`REVISION_TASKS.yaml` remains the executable provenance contract for experiment
outputs, result hashes, generated values, and artifact packaging.  The latest
non-final gate is `make check`, which validates regenerated figures, canonical
inputs, experiment outputs, source provenance, and the reproducibility package.

## Remaining finalization gate

The only intentional final-submission dependency is the archival public
artifact URL in `configs/submission_metadata.yaml`.  After that URL is inserted,
`make strict` generates `main_submission.tex` and `main_submission.pdf` with
the single-blind author metadata and final availability link.
